	Code for the experiments conducted in the paper with titled:

Knock Knock, Who’s There? Membership Inference on Aggregate Location Data
https://arxiv.org/pdf/1708.06145.pdf

------------------
File Description:
------------------

1) "subset_of_locs_prior.py": code for the first type of adversarial prior knowledge (Subset of Locations - see Sections IV.A and VI.A of the paper)

2) "same_groups_as_released_prior.py": code for the second type (2a) of adversarial prior knowledge (Same Groups As Released - see Sections IV.A and VI.B of the paper)

3) "different_groups_than_released_prior.py": code for the third type (2b) of adversarial prior knowledge (Different Groups Than Released - see Sections IV.A and VI.C of the paper)

4) "train_raw_test_dp.py": code for the experiment described in Section VII B, where the classifier is trained on raw aggregates and tested on differentially private ones

5) "train_dp_test_dp.py": code for the experiment described in Section VII B, where the classifier is trained on differentially private aggregates and tested on differentially private ones (perturbed with fresh noise)

6) README.txt : this file containing general info and guidelines

-----------
GUIDELINES
-----------

a) The code was executed on OSx Yosemite 10.01 and Ubuntu 14.04.5 with python 2.7, scikit-learn 0.19.0, pandas 0.18.1 and tsfresh 0.7.0

b) Some variables depend on the dataset in use (e.g. SFC in this case) and the kind of pre-processing that has been done to it. Thus, they should be adjusted according
the user's dataset. For example, variables like "epoch_duration", "n_epochs", "n_rois", "n_cabs", "group_sizes" should be set based on one's data. Moreover,  

"cabs.pkl": is a dataframe containing the ids of the cabs of the SFC dataset,

"attack_group1.pkl": 50 randomly sampled cabs from the highly mobile group (see Section V.A of the paper),

"attack_group2.pkl": 50 randomly sampled cabs from the mildly mobile group (see Section V.A of the paper),

"attack_group3.pkl": 50 randomly sampled cabs from the somewhat mobile group (see Section V.A of the paper) and

"ground_truth/cab_name.npz": a numpy array, in particular a binary matrix of size (n_locations, n_timeslots), where each item (i, j) is 1 if the user visited the location i at time j

c) The datasets created for each user will be stored in a dataframe in the folder "user-dfs/" (create it if non-existent). Apart from the user datasets, in case it's required the groups sampled for training and testing are stored in numpy arrays (for potential future use). Note that one should move the datasets between different experiments to avoid over-writting them.

d) The results of the script will be a dataframe stored in a folder named "results/" (create it if non-existent). Note that one should move the results between different experiments to avoid over-writting them.

e) For the code of "train_dp_test_dp.py", one can re-use for training (i.e. keep in the user-dfs folder) the differentially private datasets created in the experiment of "train_raw_test_dp.py", i.e., the files named in the form: "cabname_epsilon_dp.pkl".

f) Depending on the size of the dataset (specifically # of locations and length of their timeseries) the feature extraction process with tsfresh is heavy. Thus, a system
with multiple processors is advised.