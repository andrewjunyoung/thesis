import os as os
import pandas as pd
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from random import sample

# ts fresh for time series feature extraction
from tsfresh.feature_extraction import extract_features, MinimalFeatureExtractionSettings
from tsfresh.utilities.dataframe_functions import impute

# scikit learn modules
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix, accuracy_score, roc_curve, auc, roc_auc_score
from sklearn.preprocessing import StandardScaler

# -------------- Utility Functions --------------- #

# save a sparse matrix to disk in compressed form
def save_sparse_csr(filename, array):

    np.savez(filename, data=array.data, indices=array.indices, indptr=array.indptr, shape=array.shape)

# read a compressed matrix from disk
def load_sparse_csr(filename):

    loader = np.load(filename)
    return csr_matrix((loader['data'], loader['indices'], loader['indptr']), shape = loader['shape'])

# sample a number of cabs NOT including the target cab, and return the list of cab ids
def sample_cabs_no_target(cabs, target_cab, group_size):

    # make sure the group size cannot be larger
    assert group_size < len(cabs)

    # create a set out of the target cab
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size)

    return list(s3)

# sample a number of cabs including the target cab, and return the list of cab ids
def sample_cabs_with_target(cabs, target_cab, group_size):

    assert group_size <= len(cabs)

    # create a set out of the target cab list
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size - 1)

    # get the union of the sampled set and the target cab
    s4 = set(s3) | s1

    return list(s4)

# aggregate the sampled cabs and return the corresponding matrix
def aggregate(cabs):

    # the aggregation matrix
    agg = np.zeros( (n_rois, n_epochs) , dtype = np.int)

    for cab in cabs:

        agg = agg + ground_truth[inv_cabs_dict[cab]]

    return agg

# let's try new ways of extracting features
def extract_feats(agg):

    # keep the aggregates of the first 2 weeks for training and of the last week for testing
    tr_agg1 = agg[:, 0 * weekly_epochs: 1 * weekly_epochs]
    tr_agg2 = agg[:, 1 * weekly_epochs: 2 * weekly_epochs]
    ts_agg = agg[:, 2 * weekly_epochs: 3 * weekly_epochs]

    # create dataframes to give to tsfresh
    tr1_df = pd.DataFrame(tr_agg1.T, columns=lcols)
    tr2_df = pd.DataFrame(tr_agg2.T, columns=lcols)
    ts_df = pd.DataFrame(ts_agg.T, columns=lcols)

    # create a column id for the feature extraction
    tr1_df['id'] = 0
    tr2_df['id'] = 0
    ts_df['id'] = 0

    tr1_feat = extract_features(tr1_df, column_id='id', feature_extraction_settings=MinimalFeatureExtractionSettings() )
    tr2_feat = extract_features(tr2_df, column_id='id', feature_extraction_settings=MinimalFeatureExtractionSettings() )
    ts_feat = extract_features(ts_df, column_id='id', feature_extraction_settings=MinimalFeatureExtractionSettings() )

    # impute the features
    tr1_feat = impute(tr1_feat)
    tr2_feat = impute(tr2_feat)
    ts_feat = impute(ts_feat)

    tr1_feat = tr1_feat[feats_cols]
    tr2_feat = tr2_feat[feats_cols]
    ts_feat = ts_feat[feats_cols]

    return tr1_feat.values.ravel().tolist(), tr2_feat.values.ravel().tolist(), ts_feat.values.ravel().tolist()

# extract features for aggregates that include the target user
def features_with_target(cabs, target, group_size):

    # sample users / create aggregates / extract features for training and testing
    sample = sample_cabs_with_target(cabs, target, group_size)
    aggr = aggregate(sample)
    tr1_feat, tr2_feat, ts_feat = extract_feats(aggr)

    # append whether this row is part of the training data or not -- 0.0 corresponds to True
    tr1_feat.append(0.0)
    tr2_feat.append(0.0)

    # append whether the target user is in the dataset or not
    tr1_feat.append(0.0)
    tr2_feat.append(0.0)

    # testing data
    # append whether this row is part of training data
    ts_feat.append(1.0)

    # append whether the user is in the dataset or not
    ts_feat.append(0.0)

    return tr1_feat, tr2_feat, ts_feat

# extract features for aggregates that do not include the target user
def features_no_target(cabs, target, group_size):

    # sample users / create aggregates / extract features for training and testing
    sample = sample_cabs_no_target(cabs, target, group_size)
    aggr = aggregate(sample)
    tr1_feat, tr2_feat, ts_feat = extract_feats(aggr)

    # append whether this row is part of training or not -- 0.0 corresponds to True
    tr1_feat.append(0.0)
    tr2_feat.append(0.0)

    # append whether our target user is in the dataset or not
    tr1_feat.append(1.0)
    tr2_feat.append(1.0)

    # testing data

    # append whether this row is part of the training set
    ts_feat.append(1.0)

    # append whether the user is in the dataset or not
    ts_feat.append(1.0)

    return tr1_feat, tr2_feat, ts_feat

# create data for the user
def user_data(unique_cabs, target, group_size, cols, data_size):

    # first create a dataset for the target user
    data_array = np.zeros((data_size, len(cols)), dtype = np.float32)

    # fill the data with aggregate instances including the user
    for i in range(0, data_size, 6):
        # first with aggregate instances that include the user
        tr1_w_data, tr2_w_data, ts_w_data = features_with_target(unique_cabs, target, group_size)
        data_array[i, :] = tr1_w_data
        data_array[i + 1, :] = tr2_w_data
        data_array[i + 2, :] = ts_w_data

        # then with aggregate instances NOT including the user
        tr1_wo_data, tr2_wo_data, ts_wo_data = features_no_target(unique_cabs, target, group_size)
        data_array[i + 3, :] = tr1_wo_data
        data_array[i + 4, :] = tr2_wo_data
        data_array[i + 5, :] = ts_wo_data

    # the dataframe to store our training / testing data
    data = pd.DataFrame(data_array, columns=cols)

    data.to_pickle('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl')

    return data

# train various classifiers with the user data
def train_model(target, group_size, model, cl_name, train_data, train_labels):
    print "Training Classifier: ", cl_name
    clf = model.fit(train_data, train_labels)
    print 'Training Accuracy:', clf.score(train_data, train_labels)
    return clf

def feature_selection(train_data, train_labels):
    # estimator = RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42)
    estimator = LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42)
    selector = RFE(estimator, n_features_to_select=300, step=50)
    selector = selector.fit(train_data, train_labels)
    print '# of features:', selector.n_features_
    return selector

# evaluate how the model performs
def test_model(target, group_size, model, cl_name, test_data, test_labels):
    # create a new df to store results
    df_res_cols = [
            'cab', 'cl', 'tp', 'fp', 'fn', 'tn', 'acc', 'ppv', 'tpr', 'fpr',
            'auc', 'f1'
            ]

    # if there is a file for the users
    if os.path.isfile('results/' + 'res_' + str(group_size) + '.pkl') == True:
        res = pd.read_pickle('results/' + 'res_' + str(group_size) + '.pkl')
    else:
        res = pd.DataFrame(columns = df_res_cols)

    # make predictions with the trained model
    preds = model.predict( test_data )
    print 'Testing Accuracy:', model.score( test_data, test_labels)

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    conf = confusion_matrix(test_labels, preds, labels=[0.0, 1.0])
    acc = accuracy_score(test_labels, preds)
    ppv = precision_score(test_labels, preds, pos_label=0.0)
    rec = recall_score(test_labels, preds, pos_label=0.0)
    tnr = recall_score(test_labels, preds, pos_label=1.0)
    f1 = f1_score(test_labels, preds, pos_label=0.0)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thresholds = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(pd.Series([target, cl_name, conf[0][0], conf[1][0], conf[0][1], conf[1][1], acc, ppv, rec, 1.0 - tnr, area, f1], index = df_res_cols), ignore_index=True)

    # save the new pickle to disk
    res.to_pickle('results/' + 'res_' + str(group_size) + '.pkl')

# attack the target user
def attack_user(unique_cabs, target, group_size, cols, data_size, n_features):
    # check if there is a dataset for the target user
    if os.path.isfile('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl') == True:
        # load the user's created dataset
        data = pd.read_pickle('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl')
    else:
        print 'Sampling data...'
        # create a dataset for the user
        data = user_data(unique_cabs, target, group_size, cols, data_size)

    # define the columns of features
    features = data.columns[:n_features]

    x_train = data[data['is_train'] == 0.0]
    x_test = data[data['is_train'] == 1.0]

    x_train = x_train[features]
    x_test = x_test[features]

    y_train = x_train['is_in_the_data']
    y_test = x_test['is_in_the_data']

    # do feature elimination with RFE
    sel = feature_selection(x_train, y_train)

    x_train = sel.transform(x_train)
    x_test = sel.transform(x_test)

    print x_train.shape
    print x_test.shape

    # classifier names
    names = ["LR", "KNN", "RF", "MLP"]

    # define the classifiers and their parameters
    classifiers = [
        LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42),
        KNeighborsClassifier(5),
        RandomForestClassifier(max_depth=10, n_estimators=30, n_jobs=-1, random_state=42),
        MLPClassifier(solver='adam', hidden_layer_sizes=(200), random_state=42)]

    # train and test various classifiers
    for name, clf in zip(names, classifiers):
        if name == "MLP":
            scaler = StandardScaler()
            scaler.fit(x_train)
            x_train = scaler.transform(x_train)
            x_test = scaler.transform(x_test)

        md = train_model(target, group_size, clf, name, X_train, y_train)
        test_model(target, group_size, md, name, X_test, y_test)

# ----- Main Part of Code ------ #
if __name__== '__main__':

    # ---------- Data Setup ------------ #

    # set here how long (in minutes) each epoch is
    epoch_duration = 60

    # day epochs = 24 hour * 60 minutes / epoch_duration
    day_epochs = (24 * 60) / epoch_duration

    # 4 weeks multiplied by # of day_epochs
    n_epochs = 21 * day_epochs

    # number of epochs in a week
    week_days = 7
    weekly_epochs = week_days * 24

    unique_rois = [i for i in range(0, 100)]

    # 100 is the roi representing the 'NaN' location
    unique_rois.append(100)

    # total number of rois
    n_rois = len(unique_rois)

    # list of cab identifiers
    unique_cabs = pd.read_pickle('cabs.pkl').cab.tolist()

    # number of cabs
    n_cabs = len(unique_cabs)

    # define which cabs we want to attack - load the 3 groups of cabs we want to attack
    gr1 = pd.read_pickle('attack_group1.pkl').cab.tolist()
    gr2 = pd.read_pickle('attack_group2.pkl').cab.tolist()
    gr3 = pd.read_pickle('attack_group3.pkl').cab.tolist()

    # the final list of attack cabs
    attack_cabs = gr1 + gr2 + gr3

    cabs_dict = dict()

    # create a dictionary in the form of id:cab_name
    for k, cab in enumerate(unique_cabs):
        cabs_dict[k] = cab

    # invert the above dictionary in the form of cab_name:id
    inv_cabs_dict = {v: k for k, v in cabs_dict.iteritems()}

    # create a 3d matrix containing the ground truth of all cabs
    ground_truth = np.zeros((n_cabs, n_rois, n_epochs), dtype = np.int)

    # load the ground truth of each cab to the matrix
    # the ground_truth of each cab is a binary matrix of size (n_locations, n_timeslots), where each
    # item (i, j) is 1 if the user visited the location i at time j
    for cab in unique_cabs:

        ground_truth[inv_cabs_dict[cab]] = load_sparse_csr('ground_truth/' + str(cab) + '.npz').toarray()

    # aggregation group size
    group_sizes = [5, 10, 50, 100, 300, 500]

    # columns for the features dataframes
    lcols = []
    for i in range(0, n_rois):
        lcols.append('l' + str(i))

    # how many features do we extract - locs * # features extracted by tsfresh (8 in Minimal Setting)
    n_features = n_rois * 8

    # size of datasets for each user (must be multiple of 6)
    data_size = 450

    feats_cols = []
    for i in range(0, n_rois):
        feats_cols.append('l' + str(i) + '__variance')
        feats_cols.append('l' + str(i) + '__minimum')
        feats_cols.append('l' + str(i) + '__median')
        feats_cols.append('l' + str(i) + '__maximum')
        feats_cols.append('l' + str(i) + '__length')
        feats_cols.append('l' + str(i) + '__mean')
        feats_cols.append('l' + str(i) + '__standard_deviation')
        feats_cols.append('l' + str(i) + '__sum_values')

    # the feature columns
    cols = feats_cols + ['is_train', 'is_in_the_data']

    for group_size in group_sizes:

        print 'Group size:', group_size

        for target in attack_cabs:

            print 'User:', target
            attack_user(unique_cabs, target, group_size, cols, data_size, n_features)
