import os
import pandas as pd
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from random import sample

# ts fresh for time series feature extraction
from tsfresh.feature_extraction import extract_features, MinimalFeatureExtractionSettings
from tsfresh.utilities.dataframe_functions import impute

# scikit learn modules
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix, accuracy_score, roc_curve, roc_auc_score, auc
from sklearn.preprocessing import StandardScaler

# -------------- Utility Functions --------------- #

# save a sparse matrix to disk in compressed form
def save_sparse_csr(filename, array):
    np.savez(filename, data=array.data, indices=array.indices, indptr=array.indptr, shape=array.shape)

# read a compressed matrix from disk
def load_sparse_csr(filename):
    loader = np.load(filename)
    return csr_matrix((loader['data'], loader['indices'], loader['indptr']), shape = loader['shape'])

# save the group list to a 2 dimensional matrix each row is a group each column
def save_groups(target, groups, group_size, train, inside):
    groups_bin = np.zeros( (len(groups), n_cabs) , dtype = np.int8)

    # iterate over the group cabs to retrieve their indexes
    for i, group in enumerate(groups):
        for cab in group:
            groups_bin[i, inv_cabs_dict[cab]] = 1
    groups_bin = csr_matrix(groups_bin)

    save_sparse_csr('user-dfs/' + str(target) + '_' + str(group_size) + '_' + str(train) + '_' + str(inside), groups_bin)

# load the groups from binary matrices into a list of cabs
def load_groups(target, group_size, train, inside):
    groups_bin = load_sparse_csr('user-dfs/' + str(target) + '_' + str(group_size) + '_' + str(train) + '_' + str(inside) + '.npz').toarray()

    cabs_list = []
    for i in range(0, groups_bin.shape[0]):
        tmp = groups_bin[i, :]
        # find the indexes of the cabs
        idxs = np.where(tmp == 1)[0]

        tmp_list = []
        for idx in idxs:
            tmp_list.append(cabs_dict[idx])
        cabs_list.append(tmp_list)

    return cabs_list

# sample a number of cabs NOT including the target cab, and return the list of cab ids
def sample_cabs_no_target(cabs, target_cab, group_size):
    # make sure the group size cannot be larger
    assert group_size < len(cabs)

    # create a set out of the target cab
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size)

    return sorted(list(s3))

# sample a number of cabs including the target cab, and return the list of cab ids
def sample_cabs_with_target(cabs, target_cab, group_size):
    assert group_size <= len(cabs)

    # create a set out of the target cab list
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size - 1)

    # get the union of the sampled set and the target cab
    s4 = set(s3) | s1

    return sorted(list(s4))

# return a list of lists where each item is a group to aggregate
def sample_unique_groups(cabs, target_cab, group_size, data_size, train):
    groups_in, groups_out = [], []

    # fill the list with groups containing the user
    while(len(groups_in) < (data_size / 2.0)):
        group = sample_cabs_with_target(cabs, target_cab, group_size)
        groups_in.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_in, group_size, train, 'in')

    # fill the list with groups not containing the user
    while( len(groups_out) < (data_size / 2.0) ):
        group = sample_cabs_no_target(cabs, target_cab, group_size)
        groups_out.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_out, group_size, train, 'out')

    return groups_in, groups_out

# aggregate the sampled cabs and return the corresponding matrix
def aggregate(cabs):
    agg_matrix = np.zeros( (n_rois, n_epochs) , dtype = np.int)
    for cab in cabs:
        agg_matrix = agg_matrix + ground_truth[inv_cabs_dict[cab]]

    return agg_matrix

# let's try new ways of extracting features
def extract_feats(agg):
    # keep the aggregates of the first week
    tr_agg = agg[:, 0 * weekly_epochs: 1 * weekly_epochs]

    # create dataframes to give to tsfresh
    tr_df = pd.DataFrame(tr_agg.T, columns=lcols)

    # create a column id for the feature extraction
    tr_df['id'] = 0

    tr_feat = extract_features( tr_df, column_id='id', feature_extraction_settings=MinimalFeatureExtractionSettings() )

    # impute the features
    tr_feat = impute(tr_feat)

    # order the features, according to their names
    tr_feat = tr_feat[feats_cols]

    return tr_feat.values.ravel().tolist()

# extract features for aggregates that include the target user
def train_features_with_target(group):
    # sample users / create aggregates / extract features for training and testing
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    # append whether this row is for training or not - 0.0 --> yes
    tr_feat.append(0.0)

    # append whether the target user is in the dataset or not - 0.0 --> yes
    tr_feat.append(0.0)

    return tr_feat

# extract features for aggregates that do not include the target user
def train_features_no_target(group):

    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    # append whether this row is training or not - 0.0 --> yes
    tr_feat.append(0.0)

    # append whether our target user is in the dataset or not - 1.0 --> no
    tr_feat.append(1.0)

    return tr_feat

def test_features_with_target(group):
    # sample users / create aggregates / extract features for training and testing
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    # append whether this row is for training or not - 0.0 --> yes
    tr_feat.append(1.0)

    # append whether the target user is in the dataset or not - 0.0 --> yes
    tr_feat.append(0.0)

    return tr_feat

# extract features for aggregates that do not include the target user
def test_features_no_target(group):
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    # append whether this row is training or not - 0.0 --> yes
    tr_feat.append(1.0)

    # append whether our target user is in the dataset or not - 1.0 --> no
    tr_feat.append(1.0)

    return tr_feat

# create a dataset for the target user
def user_data(unique_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size):
    # sample groups from the prior knowledge list to train the classifier
    tr_gr_in, tr_gr_out = sample_unique_groups(prior_cabs, target, group_size, tr_data_size, 'tr')

    # first create a dataset for the target user
    tr_data_in = np.zeros((tr_data_size / 2, len(cols)), dtype = np.float32)
    tr_data_out = np.zeros((tr_data_size / 2, len(cols)), dtype = np.float32)

    # fill the data with aggregate instances including the user
    for i, j in enumerate(tr_gr_in):
        # first with aggregate instances that include the user
        tr_w_data = train_features_with_target(j)
        tr_data_in[i, :] = tr_w_data

    for i, j in enumerate(tr_gr_out):
        # then with aggregate instances NOT including the user
        tr_wo_data = train_features_no_target(j)
        tr_data_out[i, :] = tr_wo_data

    train_data_array = np.vstack((tr_data_in, tr_data_out))

    # sample groups for testing - sample from the set not in the prior knowledge
    ts_gr_in, ts_gr_out = sample_unique_groups(unique_cabs, target, group_size, ts_data_size, 'ts')

    ts_data_in = np.zeros((ts_data_size / 2, len(cols)), dtype = np.float32)
    ts_data_out = np.zeros((ts_data_size / 2, len(cols)), dtype = np.float32)

    for i, j in enumerate(ts_gr_in):
        ts_w_data = test_features_with_target(j)
        ts_data_in[i, :] = ts_w_data

    for i, j in enumerate(ts_gr_out):
        ts_wo_data = test_features_no_target(j)
        ts_data_out[i, :] = ts_wo_data

    # concat test data in and out
    test_data_array = np.vstack((ts_data_in, ts_data_out))

    # finally concat train and test data array
    data_array = np.vstack((train_data_array, test_data_array))

    # the dataframe to store our training / testing data
    data = pd.DataFrame(data_array, columns=cols)

    data.to_pickle('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl')

    return data

# train various classifiers with the user data
def train_model(target, group_size, model, cl_name, train_data, train_labels):
    # train a machine learning model given as parameter

    # fit the models to the training data
    print "Training Classifier: ", cl_name
    clf = model.fit(train_data, train_labels)
    print 'Training Accuracy:', clf.score(train_data, train_labels)

    # return the trained model
    return clf

def feature_selection(train_data, train_labels):
    # estimator = RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42)
    estimator = LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42)

    # do recursive feature elimination to keep 320 features (as the training dataset size)
    selector = RFE(estimator, n_features_to_select=tr_data_size, step=50)

    selector = selector.fit(train_data, train_labels)

    print '# of features:', selector.n_features_
    return selector

# evaluate how the model performs
def test_model(target, group_size, model, cl_name, test_data, test_labels):
    # create a new df to store results
    df_res_cols = ['cab', 'cl', 'tp', 'fp', 'fn', 'tn', 'acc', 'ppv', 'tpr', 'fpr', 'auc', 'f1']

    # if there is a file for the users
    if os.path.isfile('results/' + 'res_' + str(group_size) + '.pkl') == True:
        res = pd.read_pickle('results/' + 'res_' + str(group_size) + '.pkl')
    else:
        res = pd.DataFrame(columns = df_res_cols)

    # make predictions with the trained model
    preds = model.predict( test_data )
    print 'Testing Accuracy:', model.score( test_data, test_labels)

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    # print precision and recall
    conf = confusion_matrix(test_labels, preds, labels=[0.0, 1.0])
    acc = accuracy_score(test_labels, preds)
    ppv = precision_score(test_labels, preds, pos_label=0.0)
    rec = recall_score(test_labels, preds, pos_label=0.0)
    tnr = recall_score(test_labels, preds, pos_label=1.0)
    f1 = f1_score(test_labels, preds, pos_label=0.0)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thresholds = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(pd.Series([target, cl_name, conf[0][0], conf[1][0], conf[0][1], conf[1][1], acc, ppv, rec, 1.0 - tnr, area, f1], index = df_res_cols), ignore_index=True)

    # save the new pickle to disk
    res.to_pickle('results/' + 'res_' + str(group_size) + '.pkl')

# attack the target user
def attack_user(unique_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size, n_features):
    # If there is a dataset for the target user
    if os.path.isfile('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl') == True:
        # load the user's created dataset
        data = pd.read_pickle('user-dfs/' + str(target) + '_' + str(group_size) + '.pkl')
    else:
        print 'Sampling data...'
        # create a dataset for the user
        data = user_data(unique_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size)

    # define the columns of features
    features = data.columns[:n_features]

    # split the data to train and test parts
    X_train = data[data['is_train'] == 0.0]

    # get the train labels
    y_train = X_train['is_in_the_data']

    # keep only the features
    X_train = X_train[features]

    # define the testing set
    X_test = data[data['is_train'] == 1.0]

    # get the test labels
    y_test = X_test['is_in_the_data']

    # keep only the features
    X_test = X_test[features]

    # do feature elimination with RFE
    sel = feature_selection(X_train, y_train)

    X_train = sel.transform(X_train)
    X_test = sel.transform(X_test)

    print X_train.shape
    print X_test.shape

    # classifier names
    names = ["LR", "KNN", "RF", "MLP"]

    # define the classifiers and their parameters
    classifiers = [
        LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42),
        KNeighborsClassifier(5),
        RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42),
        MLPClassifier(solver='adam', hidden_layer_sizes=(200), random_state=42)]

    # train and test various classifiers
    for name, clf in zip(names, classifiers):
        # do feature scaling only for MLP
        if name == "MLP":
            scaler = StandardScaler()

            # Don't cheat - fit only on training data
            scaler.fit(X_train)
            X_train = scaler.transform(X_train)

            # apply same transformation to test data
            X_test = scaler.transform(X_test)

        # train the model
        md = train_model(target, group_size, clf, name, X_train, y_train)

        # evaluate the models
        test_model(target, group_size, md, name, X_test, y_test)

# ----- Main method ------ #
if __name__== '__main__':

    # ---------- Data Setup ------------ #

    # set here how long (in minutes) each epoch is
    epoch_duration = 60

    # day epochs = 24 hour * 60 minutes / epoch_duration
    day_epochs = (24 * 60) / epoch_duration

    # 3 weeks multiplied by # of day_epochs
    # e.g. 21 days and 24 hours = 504 epochs
    n_epochs = 21 * day_epochs

    # number of epochs in a week
    week_days = 7
    weekly_epochs = week_days * 24

    # we have 100 ROIs in SFC dataset
    unique_rois = [i for i in range(0, 100)]

    # 100 is the roi representing the 'NaN' location
    unique_rois.append(100)

    # total number of rois
    n_rois = len(unique_rois)

    # list of cab identifiers of the whole dataset
    unique_cabs = pd.read_pickle('cabs.pkl').cab.tolist()

    # number of cabs
    n_cabs = len(unique_cabs)

    # define which cabs we want to attack - load the 3 groups of cabs we want to attack
    gr1 = pd.read_pickle('attack_group1.pkl').cab.tolist()
    gr2 = pd.read_pickle('attack_group2.pkl').cab.tolist()
    gr3 = pd.read_pickle('attack_group3.pkl').cab.tolist()

    # the final list of attack cabs
    attack_cabs = gr1 + gr2 + gr3

    cabs_dict = dict()

    # create a dictionary in the form of id:cab_name
    for k, cab in enumerate(unique_cabs):
        cabs_dict[k] = cab

    # invert the above dictionary in the form of cab_name:id
    inv_cabs_dict = {v: k for k, v in cabs_dict.iteritems()}

    # create a 3d matrix containing the ground truth of all cabs
    ground_truth = np.zeros((n_cabs, n_rois, n_epochs), dtype = np.int)

    # load the ground truth of each cab to the matrix
    # the ground_truth of each cab is a binary matrix of size (n_locations, n_timeslots), where each
    # item (i, j) is 1 if the user visited the location i at time j
    for cab in unique_cabs:
        ground_truth[inv_cabs_dict[cab]] = load_sparse_csr('ground_truth/' + str(cab) + '.npz').toarray()

    # aggregation group size
    group_sizes = [5, 10, 50, 100]

    # columns for the features dataframes
    lcols = []
    for i in range(0, n_rois):
        lcols.append('l' + str(i))

    # the feature names for each location
    feats_cols = []
    for i in range(0, n_rois):
        feats_cols.append('l' + str(i) + '__variance')
        feats_cols.append('l' + str(i) + '__minimum')
        feats_cols.append('l' + str(i) + '__median')
        feats_cols.append('l' + str(i) + '__maximum')
        feats_cols.append('l' + str(i) + '__length')
        feats_cols.append('l' + str(i) + '__mean')
        feats_cols.append('l' + str(i) + '__standard_deviation')
        feats_cols.append('l' + str(i) + '__sum_values')

    # how many features do we extract - locs *
    # features extracted by tsfresh (8 in Minimal Setting)
    n_features = n_rois * 8

    # Set here the desired size of training / testing datasets for each user
    # Pre: must be a multiple of two
    tr_data_size = 320
    ts_data_size = 80

    # the feature columns
    cols = feats_cols + ['is_train', 'is_in_the_data']

    for target in attack_cabs:
        print 'Target:', target

        # the adversary knows only these cabs, i.e. ~20% of the data
        prior_cabs = sample(unique_cabs, 106)

        # find which pool to use for sampling test groups
        neg_prior_cabs = set(unique_cabs) - set(prior_cabs)
        neg_prior_cabs = list(neg_prior_cabs)

        for group_size in group_sizes:
            print 'Group size:', group_size

            attack_user(neg_prior_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size, n_features)
