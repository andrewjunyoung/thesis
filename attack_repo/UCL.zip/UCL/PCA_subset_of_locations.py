import os as os
import pandas as pd
import numpy as np
import pickle
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from random import sample

# scikit learn modules
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, roc_auc_score, auc

from multiprocessing import Pool

# ---------- Data Setup ------------ #

# set here how long (in minutes) each epoch is
epoch_duration = 60

# day epochs = 24 hour * 60 minutes / epoch_duration
day_epochs = (24 * 60) // epoch_duration

# 3 weeks multiplied by # of day_epochs
# e.g. 21 days and 24 hours = 504 epochs
n_epochs = 21 * day_epochs

# number of epochs in a week
week_days = 7
weekly_epochs = week_days * 24

unique_rois = [i for i in range(0, 100)]

# 100 is the roi representing the 'NaN' location
unique_rois.append(100)

# total number of rois
n_rois = len(unique_rois)

# list of cab identifiers
unique_cabs = pd.read_pickle('cabs.pkl').cab.tolist()

# number of cabs
n_cabs = len(unique_cabs)

# define which cabs we want to attack - load the 3 groups of cabs we want to attack
gr1 = pd.read_pickle('group1.pkl').cab.tolist()
gr2 = pd.read_pickle('group2.pkl').cab.tolist()
gr3 = pd.read_pickle('group3.pkl').cab.tolist()

# the final list of attack cabs
attack_cabs = gr1 + gr2 + gr3

cabs_dict = dict()

# create a dictionary in the form of id:cab_name
for k, cab in enumerate(unique_cabs):
    cabs_dict[k] = cab

# invert the above dictionary in the form of cab_name:id
inv_cabs_dict = {v: k for k, v in cabs_dict.items()}

# -------------- Utility Functions --------------- #

# save the group list to a 2 dimensional matrix each row is a group each column
def save_groups(target, groups, group_size, train, inside):

    groups_bin = np.zeros( (len(groups), n_cabs) , dtype = np.int8)

    # iterate over the group cabs to retrieve their indexes
    for i, group in enumerate(groups):

        for cab in group:

            groups_bin[i, inv_cabs_dict[cab]] = 1

    groups_bin = csr_matrix(groups_bin)

    save_sparse_csr('user_dfs/' + str(target) + '_' + str(group_size) + '_' + str(train) + '_' + str(inside), groups_bin)

# load the groups from binary matrices into a list of cabs
def load_groups(target, group_size, train, inside):

    groups_bin = load_sparse_csr('user_dfs/' + str(target) + '_' + str(group_size) + '_' + str(train) + '_' + str(inside) + '.npz').toarray()

    cabs_list = []

    for i in range(0, groups_bin.shape[0]):

        tmp = groups_bin[i, :]

        # find the indexes of the cabs
        idxs = np.where(tmp == 1)[0]

        tmp_list = []

        for idx in idxs:

            tmp_list.append(cabs_dict[idx])

        cabs_list.append(tmp_list)

    return cabs_list

# save a sparse matrix to disk in compressed form
def save_sparse_csr(filename, array):

    np.savez(filename, data=array.data, indices=array.indices, indptr=array.indptr, shape=array.shape)

# read a compressed matrix from disk
def load_sparse_csr(filename):

    loader = np.load(filename)
    return csr_matrix((loader['data'], loader['indices'], loader['indptr']), shape = loader['shape'])

# sample a number of cabs NOT including the target cab, and return the list of cab ids
def sample_cabs_no_target(cabs, target_cab, group_size):

    # make sure the group size cannot be larger
    assert group_size < len(cabs)

    # create a set out of the target cab
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size)

    return sorted(list(s3))

# sample a number of cabs including the target cab, and return the list of cab ids
def sample_cabs_with_target(cabs, target_cab, group_size):

    assert group_size <= len(cabs)

    # create a set out of the target cab list
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size - 1)

    # get the union of the sampled set and the target cab
    s4 = set(s3) | s1

    return sorted(list(s4))

# return a list of lists where each item is a group to aggregate
def sample_unique_groups(cabs, target_cab, group_size, data_size, train):

    groups_in = []
    groups_out = []

    # fill the list with groups containing the user
    while( len(groups_in) < (data_size // 2.0) ):

        group = sample_cabs_with_target(cabs, target_cab, group_size)
        groups_in.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_in, group_size, train, 'in')

    # fill the list with groups not containing the user
    while( len(groups_out) < (data_size // 2.0) ):

        group = sample_cabs_no_target(cabs, target_cab, group_size)
        groups_out.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_out, group_size, train, 'out')

    return groups_in, groups_out

# aggregate the sampled cabs and return the corresponding matrix
def aggregate(cabs):
    # the aggregation matrix
    agg = np.zeros( (n_rois, weekly_epochs) , dtype = np.int16())
    for cab in cabs:
        agg = agg + ground_truth[inv_cabs_dict[cab]]
    return agg

# just serialize the aggregates
def extract_feats(agg):
    return agg.ravel().tolist()

# extract features for aggregates that include the target user
def train_features_with_target(group):
    # sample users / create aggregates / extract features for training and testing
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    del aggr

    # append whether this row is for training or not - 0.0 --> yes
    tr_feat.append(0.0)
    # append whether the target user is in the dataset or not - 0.0 --> yes
    tr_feat.append(0.0)

    return tr_feat

# extract features for aggregates that do not include the target user
def train_features_no_target(group):
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    del aggr

    # append whether this row is training or not - 0.0 --> yes
    tr_feat.append(0.0)
    # append whether our target user is in the dataset or not - 1.0 --> no
    tr_feat.append(1.0)

    return tr_feat

def test_features_with_target(group):
    # sample users / create aggregates / extract features for training and testing
    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    del aggr

    # append whether this row is for training or not - 1.0 --> no
    tr_feat.append(1.0)
    # append whether the target user is in the dataset or not - 0.0 --> yes
    tr_feat.append(0.0)

    return tr_feat

# extract features for aggregates that do not include the target user
def test_features_no_target(group):

    aggr = aggregate(group)
    tr_feat = extract_feats(aggr)

    del aggr

    # append whether this row is for training or not - 1.0 --> no
    tr_feat.append(1.0)

    # append whether our target user is in the dataset or not - 1.0 --> no
    tr_feat.append(1.0)

    return tr_feat

# create a dataset for the target user
def user_data(unique_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size):

    # sample groups from the prior knowledge list to train the classifier
    tr_gr_in, tr_gr_out = sample_unique_groups(prior_cabs, target, group_size, tr_data_size, 'tr')

    # first create a dataset for the target user
    tr_data_in = np.zeros((tr_data_size // 2, len(cols)), dtype = np.int16)
    tr_data_out = np.zeros((tr_data_size // 2, len(cols)), dtype = np.int16)

    # fill the data with aggregate instances including the user
    for i, j in enumerate(tr_gr_in):

        # first with aggregate instances that include the user
        tr_w_data = train_features_with_target(j)
        tr_data_in[i, :] = tr_w_data
        del tr_w_data

    for i, j in enumerate(tr_gr_out):

        # then with aggregate instances NOT including the user
        tr_wo_data = train_features_no_target(j)
        tr_data_out[i, :] = tr_wo_data
        del tr_wo_data

    train_data_array = np.vstack((tr_data_in, tr_data_out))
    del tr_gr_in, tr_gr_out
    del tr_data_in, tr_data_out

    # sample groups for testing - sample from the whole list of cabs
    ts_gr_in, ts_gr_out = sample_unique_groups(unique_cabs, target, group_size, ts_data_size, 'ts')

    ts_data_in = np.zeros((ts_data_size // 2, len(cols)), dtype = np.int16)
    ts_data_out = np.zeros((ts_data_size // 2, len(cols)), dtype = np.int16)

    for i, j in enumerate(ts_gr_in):

        ts_w_data = test_features_with_target(j)
        ts_data_in[i, :] = ts_w_data
        del ts_w_data

    for i, j in enumerate(ts_gr_out):

        ts_wo_data = test_features_no_target(j)
        ts_data_out[i, :] = ts_wo_data
        del ts_wo_data

    # concat test data in and out
    test_data_array = np.vstack((ts_data_in, ts_data_out))
    del ts_gr_in, ts_gr_out
    del ts_data_in, ts_data_out

    # finally concat train and test data array
    data_array = np.vstack((train_data_array, test_data_array))
    del train_data_array, test_data_array

    data = np.nan_to_num(data_array)

    # save the dataset for future use
    np.savez('user_dfs/' + str(target) + '_' + str(group_size) + '.npz', data)

def dim_reduction(train_data):

    # reduce the dataset dimensions from 101 * 168 = 16,968 to 500 principal components
    # (potentially less components are sufficient for the attack)
    pca = PCA(n_components= tr_data_size // 4, svd_solver='randomized', random_state=42)
    pca.fit(train_data)

    return pca

# train various classifiers with the user data
def train_model(target, group_size, model, cl_name, train_data, train_labels):

    # train a machine learning model given as parameter

    # fit the models to the training data
    print("Training Classifier: ", cl_name)
    clf = model.fit(train_data, train_labels)
    print('Training Accuracy:', clf.score(train_data, train_labels))

    np.savez('user_dfs/' + str(target) + '_coeffs.npz', clf.coef_)

    # return the trained model
    return clf

# evaluate how the model performs
def test_model(target, group_size, model, cl_name, test_data, test_labels):

    # create a new df to store results
    df_res_cols = ['cab', 'cl', 'auc']

    # if there is a file for the users
    if os.path.isfile('results/' + 'res_' + str(group_size) + '.pkl') == True:

        res = pd.read_pickle('results/' + 'res_' + str(group_size) + '.pkl')

    else:

        res = pd.DataFrame(columns = df_res_cols)

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thresholds = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(pd.Series([target, cl_name, area], index = df_res_cols), ignore_index=True)

    # save the new pickle to disk
    res.to_pickle('results/' + 'res_' + str(group_size) + '.pkl')

# attack the target user
def attack_user(target, group_size, cols, tr_data_size, ts_data_size, n_features):

    # create a dataset for the user
    data = np.load('user_dfs/' + str(target) + '_' + str(group_size) + '.npz')['arr_0']

    # the dataframe to store our training // testing data
    data = pd.DataFrame(data, columns=cols)

    # define the columns of features
    features = data.columns[:n_features]

    # split the data to train and test parts
    X_train = data[data['is_train'] == 0.0]

    # get the train labels
    y_train = X_train['is_in_the_data']

    # keep only the features
    X_train = X_train[features]

    # define the testing set and repeat testing 100 times
    X_test = data[data['is_train'] == 1.0]

    # get the test labels
    y_test = X_test['is_in_the_data']

    # keep only the features
    X_test = X_test[features]

    # scale the data before PCA
    scaler = StandardScaler()
    scaler.fit(X_train)
    X_train = scaler.transform(X_train)
    X_test = scaler.transform(X_test)

    # do dimensionality reduction with PCA
    sel = dim_reduction(X_train)
    X_train = sel.transform(X_train)
    X_test = sel.transform(X_test)

    print(X_train.shape)
    print(X_test.shape)

    np.savez('user_dfs/' + str(target) + '_components.npz', sel.components_)
    np.savez('user_dfs/' + str(target) + '_explained_variance.npz', sel.explained_variance_ratio_)

    # classifier names
    names = ["LR"]

    # define the classifiers and their parameters
    classifiers = [LogisticRegression(solver='liblinear', random_state=42)]

    # train and test various classifiers
    for name, clf in zip(names, classifiers):

        # train the model
        md = train_model(target, group_size, clf, name, X_train, y_train)

        # evaluate the models
        test_model(target, group_size, md, name, X_test, y_test)

def attack_data(users):
    for target in users:
        print('Target:', target)

        # the adversary knows the data of these cabs - \alpha = 0.5, i.e., 534 / 2 = 267 cabs
        prior_cabs = sample(unique_cabs, 267)

        neg_prior_cabs = set(unique_cabs) - set(prior_cabs)
        neg_prior_cabs = list(neg_prior_cabs)

        user_data(neg_prior_cabs, prior_cabs, target, group_size, cols, tr_data_size, ts_data_size)

# ----- Main Part of Code ------ #

# create a 3d matrix containing the ground truth of all cabs
ground_truth = np.zeros((n_cabs, n_rois, weekly_epochs), dtype = np.int8)

# load the ground truth of each cab to the matrix
# the ground_truth of each cab is a binary matrix of size (n_locations, n_timeslots), where each
# item (i, j) is 1 if the user visited the location i at time j
for cab in unique_cabs:
    ground_truth[inv_cabs_dict[cab]] = load_sparse_csr('ground_truth/' + str(cab) + '.npz').toarray()[:, 0 * weekly_epochs:1*weekly_epochs]

# aggregation group size
group_size = 300

print('Group size:', group_size)

# columns for the features dataframes
lcols = []
for i in range(0, n_rois):
    for j in range(0, weekly_epochs):
        lcols.append('l' + str(i) + 't' + str(j))

# how many features we have
n_features = n_rois * weekly_epochs

# size of datasets for each user
tr_data_size = 2000
ts_data_size = 400

# the feature columns
cols = lcols + ['is_train', 'is_in_the_data']

# set the number of processsors of the system that you want (are allowed) to occupy
n_processes = 15

# parallelize the generation of aggregates for the users
for l in range(0, len(attack_cabs), n_processes):

    attack_batches = [ [x] for x in attack_cabs[l:l+n_processes] ]

    # parallelize the feature extraction
    p = Pool(n_processes)
    p.map(attack_data, attack_batches, chunksize=1)
    p.close()
    p.join()

# run the attack sequentially
for target in attack_cabs:

    attack_user(target, group_size, cols, tr_data_size, ts_data_size, n_features)
