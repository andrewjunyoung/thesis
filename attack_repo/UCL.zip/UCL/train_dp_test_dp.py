import os as os
import pandas as pd
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from random import sample
import cPickle

# ts fresh for time series feature extraction
from tsfresh.feature_extraction import extract_features, MinimalFeatureExtractionSettings
from tsfresh.utilities.dataframe_functions import impute

# scikit learn modules
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix, accuracy_score, roc_curve, roc_auc_score, auc
from sklearn.preprocessing import StandardScaler

# -------------- Utility Functions --------------- #

# save the group list to a 2 dimensional matrix each row is a group each column
def save_groups(target, groups, group_size, inside):

    groups_bin = np.zeros( (len(groups), n_cabs) , dtype = np.int8)

    # iterate over the group cabs to retrieve their indexes
    for i, group in enumerate(groups):

        for cab in group:

            groups_bin[i, inv_cabs_dict[cab]] = 1

    groups_bin = csr_matrix(groups_bin)

    save_sparse_csr('user-dfs/' + str(target) + '_' + str(group_size) + '_' + str(inside), groups_bin)

# load the groups from binary matrices into a list of cabs
def load_groups(target, group_size, inside):

    groups_bin = load_sparse_csr('user-dfs/' + str(target) + '_' + str(group_size) + '_' + str(inside) + '.npz').toarray()

    cabs_list = []

    for i in range(0, groups_bin.shape[0]):

        tmp = groups_bin[i, :]

        # find the indexes of the cabs
        idxs = np.where(tmp == 1)[0]

        tmp_list = []

        for idx in idxs:

            tmp_list.append(cabs_dict[idx])

        cabs_list.append(tmp_list)

    return cabs_list

# save a sparse matrix to disk in compressed form
def save_sparse_csr(filename, array):

    np.savez(filename, data=array.data, indices=array.indices, indptr=array.indptr, shape=array.shape)

# read a compressed matrix from disk
def load_sparse_csr(filename):

    loader = np.load(filename)
    return csr_matrix((loader['data'], loader['indices'], loader['indptr']), shape = loader['shape'])

# sample a number of cabs NOT including the target cab, and return the list of cab ids
def sample_cabs_no_target(cabs, target_cab, group_size):

    # make sure the group size cannot be larger
    assert group_size < len(cabs)

    # create a set out of the target cab
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size)

    return sorted(list(s3))

# sample a number of cabs including the target cab, and return the list of cab ids
def sample_cabs_with_target(cabs, target_cab, group_size):

    assert group_size <= len(cabs)

    # create a set out of the target cab list
    s1 = set([target_cab])

    # create a set out of the rest of cabs and convert it to list
    s2 = list( set(cabs) - s1 )

    # sample the cabs list not containing the target
    s3 = sample(s2, group_size - 1)

    # get the union of the sampled set and the target cab
    s4 = set(s3) | s1

    return sorted(list(s4))

# aggregate the sampled cabs and return the corresponding matrix
def aggregate(cabs):

    # the aggregation matrix
    agg = np.zeros( (n_rois, n_epochs) , dtype = np.int)

    for cab in cabs:

        agg = agg + ground_truth[inv_cabs_dict[cab]]

    return agg[:, 0 * weekly_epochs: 1 * weekly_epochs]

# LPA
def add_laplacian_noise(agg, sensitivity, epsilon):

    # calculate the noise scale we need to inject
    noise_scale = sensitivity / epsilon

    # noise matrix
    noise = np.random.laplace(scale=noise_scale, size = agg.shape)

    # calculate the perturbed aggregates and round them to the nearest integer
    pert_agg = agg.astype(np.float32()) + noise
    pert_agg = np.round(pert_agg).astype(np.int16())

    # quantize values larger than the cab population to 534
    pert_agg[pert_agg > n_cabs] = n_cabs

    # quantize values smaller than zero to zero
    pert_agg[pert_agg < 0] = 0

    return pert_agg

# GSM
def add_gaussian_noise(agg, sensitivity, epsilon, delta):

    noise_scale = np.sqrt(2 * np.log(2 / delta)) * np.sqrt(sensitivity) / epsilon

    # noise matrix
    noise = np.random.normal(loc=0.0, scale = noise_scale, size = agg.shape)

    pert_agg = agg.astype(np.float32()) + noise
    pert_agg = np.round(pert_agg).astype(np.int16())

    # quantize values larger than the cab population to 534
    pert_agg[pert_agg > n_cabs] = n_cabs

    # quantize values smaller than zero to zero
    pert_agg[pert_agg < 0.0] = 0.0

    return pert_agg

# FPA
def fpa(agg, coeffs, sensitivity, epsilon):

    sens = np.sqrt(coeffs) * np.sqrt(sensitivity)

    noise_scale = sens / epsilon

    # add noise to real and imaginary parts of fft coeffs
    noise = np.random.laplace(scale=noise_scale, size = (agg.shape[0], coeffs))
    noise1 = np.random.laplace(scale=noise_scale, size = (agg.shape[0], coeffs)) * 1j

    fft_agg = np.fft.fft(agg, axis=1)[:, 0:coeffs]

    interm_agg = fft_agg + noise + noise1

    zeros = np.zeros((agg.shape[0], agg.shape[1] - coeffs))

    interm_agg = np.hstack((interm_agg, zeros))

    pert_agg = np.fft.ifft(interm_agg)

    pert_agg = np.round(pert_agg).astype(np.int16())

    pert_agg[pert_agg > n_cabs] = n_cabs

    # quantize values smaller than zero to zero
    pert_agg[pert_agg < 0.0] = 0.0

    return pert_agg

# let's try new ways of extracting features
def extract_feats(agg):

    # keep the aggregates of one week
    tr_agg = agg

    # create dataframes to give to tsfresh
    tr_df = pd.DataFrame(tr_agg.T, columns=lcols)

    # create a column id for the feature extraction
    tr_df['id'] = 0

    tr_feat = extract_features(tr_df, column_id='id', feature_extraction_settings=MinimalFeatureExtractionSettings() )

    # impute the features
    tr_feat = impute(tr_feat)

    tr_feat = tr_feat[feats_cols]

    return tr_feat.values.ravel().tolist()

# extract features for aggregates that include the target user
def features_with_target_dp(group, sensitivity, epsilon):

    raw_aggr = aggregate(group)

    # add DP and extract features again
    dp_aggr = add_laplacian_noise(raw_aggr, sensitivity, epsilon)
    # dp_aggr = fpa(raw_aggr, 20, sensitivity, epsilon)
    # dp_aggr = add_gaussian_noise(raw_aggr, sensitivity, epsilon, 0.1)

    dp_feat = extract_feats(dp_aggr)

    # append whether the target user is in the dataset or not - 0.0 --> yes
    dp_feat.append(0.0)

    return dp_feat

# extract features for aggregates that do not include the target user
def features_no_target_dp(group, sensitivity, epsilon):

    raw_aggr = aggregate(group)

    # add DP and re-extract features
    dp_aggr = add_laplacian_noise(raw_aggr, sensitivity, epsilon)
    # dp_aggr = fpa(raw_aggr, 20, sensitivity, epsilon)
    # dp_aggr = add_gaussian_noise(raw_aggr, sensitivity, epsilon, 0.1)

    dp_feat = extract_feats(dp_aggr)

    dp_feat.append(1.0)

    return dp_feat

# return a list of lists where each item is a group to aggregate
def sample_unique_groups(cabs, target_cab, group_size, data_size):

    # if exist the sampled groups
    if os.path.isfile('user-dfs/' + str(target) + '_' + str(group_size) + '_in' + '.npz') == True:

        print 'loading files...'
        groups_in = load_groups(target, group_size, 'in')
        groups_out = load_groups(target, group_size, 'out')

    else:

        # the new unique groups
        groups_in = []
        groups_out = []

        # fill the list with groups containing the user
        while( len(groups_in) < (data_size / 2) ):

            group = sample_cabs_with_target(cabs, target_cab, group_size)

            if group not in groups_in:
                groups_in.append(group)

        # save the groups to disk for future use
        save_groups(target_cab, groups_in, group_size, 'in')

        # fill the list with groups not containing the user
        while( len(groups_out) < (data_size / 2) ):

            group = sample_cabs_no_target(cabs, target_cab, group_size)

            if group not in groups_out:
                groups_out.append(group)

        # save the groups to disk for future use
        save_groups(target_cab, groups_out, group_size, 'out')

    return groups_in, groups_out

# create differentially private including and excluding the user
def dp_train_test_data(unique_cabs, target, group_size, cols, data_size, sensitivity):

    # sample the unique groups containing and not the user
    gr_in, gr_out = sample_unique_groups(unique_cabs, target, group_size, data_size)

    # extract features from DP aggregates for testing
    for epsilon in epsilons:

        print 'Extracting features Epsilon:', epsilon

        data_in_dp = np.zeros((data_size / 2, len(cols)), dtype = np.float32)
        data_out_dp = np.zeros((data_size / 2, len(cols)), dtype = np.float32)

        for i, j in enumerate(gr_in):

            # first with aggregate instances that include the user
            dp_w_data = features_with_target_dp(j, sensitivity, epsilon)
            data_in_dp[i, :] = dp_w_data

        for i, j in enumerate(gr_out):

            # then with aggregate instances NOT including the user
            dp_wo_data = features_no_target_dp(j, sensitivity, epsilon)
            data_out_dp[i, :] = dp_wo_data

        # create the features for the dp aggregates
        dp_data_array = np.vstack((data_in_dp, data_out_dp))
        dp_data = pd.DataFrame(dp_data_array, columns=cols)
        dp_data.to_pickle('user-dfs/'  + str(target) + '_' + str(epsilon) + '_test_dp.pkl')

        del data_in_dp, data_out_dp
        del dp_data, dp_data_array

# train various classifiers with the user data
def train_model(target, group_size, model, cl_name, train_data, train_labels):

    # train a machine learning model given as parameter

    # fit the models to the training data
    print "Training Classifier: ", cl_name
    clf = model.fit(train_data, train_labels)
    print 'Training Accuracy:', clf.score(train_data, train_labels)

    # return the trained model
    return clf

def feature_selection(train_data, train_labels):

    # estimator = RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42)
    estimator = LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42)

    # keep 250 features
    selector = RFE(estimator, n_features_to_select=400, step=100)

    selector = selector.fit(train_data, train_labels)

    print '# of features:', selector.n_features_
    return selector

# evaluate how the model performs
def test_model(target, group_size, model, cl_name, test_data, test_labels, epsilon):

    # create a new df to store results
    df_res_cols = ['cab', 'cl', 'tp', 'fp', 'fn', 'tn', 'acc', 'ppv', 'tpr', 'fpr', 'auc', 'f1']

    # if there is a file for the users
    if os.path.isfile('results/' + 'res_' + str(group_size) + '_' + str(epsilon) + '.pkl') == True:

        res = pd.read_pickle('results/' + 'res_' + str(group_size) + '_' + str(epsilon)+ '.pkl')

    else:

        res = pd.DataFrame(columns = df_res_cols)

    # make predictions with the trained model
    preds = model.predict( test_data )
    print 'Testing Accuracy:', model.score( test_data, test_labels)

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    # print precision and recall
    conf = confusion_matrix(test_labels, preds, labels=[0.0, 1.0])
    acc = accuracy_score(test_labels, preds)
    ppv = precision_score(test_labels, preds, pos_label=0.0)
    rec = recall_score(test_labels, preds, pos_label=0.0)
    tnr = recall_score(test_labels, preds, pos_label=1.0)
    f1 = f1_score(test_labels, preds, pos_label=0.0)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thres = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(pd.Series([target, cl_name, conf[0][0], conf[1][0], conf[0][1], conf[1][1], acc, ppv, rec, 1.0 - tnr, area, f1], index = df_res_cols), ignore_index=True)

    # save the new pickle to disk
    res.to_pickle('results/' + 'res_' + str(group_size) + '_' + str(epsilon) + '.pkl')

# attack the target user
def attack_user(unique_cabs, target, group_size, cols, data_size, n_features, sensitivity):

    # now let's create 5 test datasets
    dp_train_test_data(unique_cabs, target, group_size, cols, data_size, sensitivity)

    # classifier names
    names = ["LR", "KNN", "RF", "MLP"]

    # define the classifiers and their parameters
    classifiers = [
        LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42),
        KNeighborsClassifier(1),
        RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42),
        MLPClassifier(solver='adam', hidden_layer_sizes=(200), random_state=42)]

    # train and test various classifiers
    for name, clf in zip(names, classifiers):

        # then test the model on the dp test data
        for epsilon in epsilons:

            # train on the previously extracted dp aggregates
            train_data = pd.read_pickle('user-dfs/' + str(target) + '_' + str(epsilon) + '_dp.pkl')

            features = train_data.columns[:n_features]

            # load the training set and labels
            X_train = train_data[features]
            y_train = train_data['is_in_the_data']

            # do feature elimination with RFE
            sel = feature_selection(X_train, y_train)

            X_train = sel.transform(X_train)

            # test on the freshly extracted dp aggregates
            test_data = pd.read_pickle('user-dfs/' + str(target) + '_' + str(epsilon) + '_test_dp.pkl')

            X_test = test_data[features]
            y_test = test_data['is_in_the_data']

            X_test = sel.transform(X_test)

            # do feature scaling only for MLP
            scaler = StandardScaler()

            # do feature scaling only for MLP
            if name == "MLP":

                # Don't cheat - fit only on training data
                scaler.fit(X_train)
                X_train = scaler.transform(X_train)

                # apply same transformation to test data
                X_test = scaler.transform(X_test)

            # train the model on the raw training data
            md = train_model(target, group_size, clf, name, X_train, y_train)

            # first test the model on the raw test data
            test_model(target, group_size, md, name, X_test, y_test, epsilon)

            del X_train, y_train
            del X_test, y_test

# ----- Main Part of Code ------ #

if __name__== '__main__':

    # ---------- Data Setup ------------ #

    # set here how long (in minutes) each epoch is
    epoch_duration = 60

    # day epochs = 24 hour * 60 minutes / epoch_duration
    day_epochs = (24 * 60) / epoch_duration

    # 3 weeks multiplied by # of day_epochs
    n_epochs = 21 * day_epochs

    # number of epochs in a week
    week_days = 7
    weekly_epochs = week_days * 24

    unique_rois = [i for i in range(0, 100)]

    # 100 is the roi representing the 'NaN' location
    unique_rois.append(100)

    # total number of rois
    n_rois = len(unique_rois)

    # list of cab identifiers
    unique_cabs = pd.read_pickle('cabs.pkl').cab.tolist()

    # number of cabs
    n_cabs = len(unique_cabs)

    # define which cabs we want to attack - load the 3 groups of cabs we want to attack
    gr1 = pd.read_pickle('attack_group1.pkl').cab.tolist()
    gr2 = pd.read_pickle('attack_group2.pkl').cab.tolist()
    gr3 = pd.read_pickle('attack_group3.pkl').cab.tolist()

    # the final list of attack cabs
    attack_cabs = gr1 + gr2 + gr3

    cabs_dict = dict()

    # create a dictionary in the form of id:cab_name
    for k, cab in enumerate(unique_cabs):
        cabs_dict[k] = cab

    # invert the above dictionary in the form of cab_name:id
    inv_cabs_dict = {v: k for k, v in cabs_dict.iteritems()}

    # create a 3d matrix containing the ground truth of all cabs
    ground_truth = np.zeros((n_cabs, n_rois, n_epochs), dtype = np.int)

    # load the ground truth of each cab to the matrix
    for cab in unique_cabs:

        ground_truth[inv_cabs_dict[cab]] = load_sparse_csr('ground_truth/' + str(cab) + '.npz').toarray()

    # aggregation group size
    group_size = 500

    # dp epsilon values
    epsilons = [0.01, 0.1, 1.0, 10.0]

    # columns for the features dataframes
    lcols = []
    for i in range(0, n_rois):
        lcols.append('l' + str(i))

    # how many features do we extract - locs * # features extracted by tsfresh (222 full features)
    n_features = n_rois * 8

    # size of datasets for each user
    data_size = 400

    # the feature columns
    feats_cols = []
    for i in range(0, n_rois):
        feats_cols.append('l' + str(i) + '__variance')
        feats_cols.append('l' + str(i) + '__minimum')
        feats_cols.append('l' + str(i) + '__median')
        feats_cols.append('l' + str(i) + '__maximum')
        feats_cols.append('l' + str(i) + '__length')
        feats_cols.append('l' + str(i) + '__mean')
        feats_cols.append('l' + str(i) + '__standard_deviation')
        feats_cols.append('l' + str(i) + '__sum_values')

    cols = feats_cols + ['is_in_the_data']

    for target in attack_cabs:

        # sensitivity for each user
        # sensitivity = 1.0 # ONLY if LPA(1 / epsilon) is tested
        sensitivity = 2685.0 # global sensitivity for the 1st week of the SFC dataset

        print 'User:', target

        attack_user(unique_cabs, target, group_size, cols, data_size, n_features, sensitivity)
