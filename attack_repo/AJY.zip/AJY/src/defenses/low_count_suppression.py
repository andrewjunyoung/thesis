"""
Description: Functions used to implement low count suppression on MI attacks.
Author: Andrew J. Young at Imperial College London.
"""

## Begin imports ###############################################################

from numpy import ndarray

################################################################# End imports ##
## Begin uility functions ######################################################

# Returns true  iff an aggregate is deemed to have a low count,
#         false otherwise

def is_low_count(agg: ndarray, threshold: int) -> bool:
    for i in range(agg.shape[0]):
        for j in range(agg.shape[1]):
            if agg[i, j] < threshold:
                return True
    return False

# Edits counts which are below the threshold to be 0.
def suppress_low_counts(agg: ndarray, threshold: int) -> ndarray:
    for i in range(agg.shape[0]):
        for j in range(agg.shape[1]):
            if agg[i, j] < threshold:
                agg[i, j] = 0
    return agg

######################################################## End uility functions ##

