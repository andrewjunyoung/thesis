"""
Description: Functions to implement perturbation methods onto aggregates which
add noise to the aggregate itself.
Author: Andrew J. Young at Imperial College London
"""

## Begin imports ###############################################################

# APIs
from numpy import ndarray, random, zeros
import sys

################################################################# End imports ##
## Begin utility functions #####################################################

# Adds noise to every element in a numpy array and returns the perturbed array.
# We are most interested in laplacian and normal noise addition.
def add_noise(agg: ndarray, noise_params: tuple, group_size: int) -> ndarray:
    assert group_size > 0

    scaling = scale_factor(noise_params, group_size)

    if noise_params[0] == "Laplacian":
        noise = random.laplace
    elif noise_params[0] == "Normal":
        noise = random.normal
    else:
        print("Error: Invalid noise function used. Exiting.")
        # Kill the whole program.
        sys.exit()

    perturbed_agg = zeros(agg.shape, agg.dtype)
    agg_x_len, agg_y_len = agg.shape
    for i in range(agg_x_len):
        for j in range(agg_y_len):
            perturbed_agg[i, j] = noise(agg[i, j], scaling)
    return perturbed_agg

# Returns the scale factor to be used for noise addition.
# If the value of DEFENSES["Low count suppression]" is invalid, the scale factor
# will be set to 0.
def scale_factor(noise_params: tuple, group_size: int) -> float:
    assert group_size > 0

    if noise_params[0] == "Laplacian":
        if noise_params[1] == "Delta / epsilon":
            return group_size / noise_params[2]
        if noise_params[1] == "1 / epsilon":
            return 1 / noise_params[2]
    if noise_params[0] == "Normal":
        return noise_params[1]

    print("Something may have gone wrong with scaling. Check your parameters")
    sys.exit()

####################################################### End utility functions ##

