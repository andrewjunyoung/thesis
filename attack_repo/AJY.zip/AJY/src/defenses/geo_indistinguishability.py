"""
Description: Functions used to implement geoindistinguishability on MI attacks.
Author: Andrew J. Young at Imperial College London.
"""

## Begin imports ###############################################################

from pandas import DataFrame
from src.utils.geo_indistinguishability import PlanarLaplaceNoise
from src.settings.main import *

################################################################# End imports ##
## Begin constants #############################################################
SALT = "5zeiqtb1"
############################################################### End constants ##
## Begin uility functions ######################################################

def geo_ind_df(epsilon: float, df: DataFrame, ID2LATLONG) -> DataFrame:
    planar_laplace_noise = PlanarLaplaceNoise(epsilon, ID2LATLONG)

    new_events = []
    for index, row in df.iterrows():
        new_point_id = planar_laplace_noise(10 * row.lat + row.long, SALT,
                row.epoch)
        new_events.append([row.target, new_point_id // 10, new_point_id % 10,
            row.epoch])

    return DataFrame(new_events, columns=COLUMNS)

######################################################## End uility functions ##

