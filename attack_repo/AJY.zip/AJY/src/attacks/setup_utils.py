# -*- coding: utf-8 -*-

"""
Description: A series of utility functions to implement membership inference
(MI) attacks following the specification in Pyrgelis et al's 2017 paper "Knock
knock, who's there: Membership inference on aggregate location data".

Author: Andrew J. Young at Imperial College London.
"""

## Begin imports ###############################################################

# APIs
from os import path
from numpy import savez, zeros, load, int8, where, ndarray
from pandas import DataFrame, read_pickle, Series
from random import sample
from scipy.sparse import csr_matrix
from threading import Lock
from typing import List, Dict, Any, TypeVar

# Relative file references
from src.settings.main import *
from src.utils.rw_lock import RWLock

################################################################# End imports ##

class ConstantsObject(object):
    def __init__(
            self, CABS, FEATS_COLS, COLS, DATA_SIZE, N_FEATURES, GROUND_TRUTH,
            INVERTED_CABS_DICT, LCOLS, GROUP_LOCKS, TARGET_LOCKS, N_CABS
            ):
        self.CABS = CABS
        self.COLS = COLS
        self.DATA_SIZE = DATA_SIZE
        self.N_FEATURES = N_FEATURES
        self.GROUND_TRUTH = GROUND_TRUTH
        self.INVERTED_CABS_DICT = INVERTED_CABS_DICT
        self.LCOLS = LCOLS
        self.FEATS_COLS = FEATS_COLS
        self.GROUP_LOCKS = GROUP_LOCKS
        self.TARGET_LOCKS = TARGET_LOCKS
        self.N_CABS = N_CABS


# Save a sparse matrix to disk in compressed form
def save_sparse_csr(filename: str, array) -> None:
    savez(
            filename, data=array.data, indices=array.indices,
            indptr=array.indptr, shape=array.shape
            )


    # Read a compressed matrix from disk.
def load_sparse_csr(filename: str):
    loader = load(filename)
    return csr_matrix((loader['data'], loader['indices'], loader['indptr']),
            shape = loader['shape'])


    # Save the group list to a 2 dimensional matrix each row is a group each column
def save_groups(
        target: str, samples: List[str], group_size: int, inside: str,
        constants: ConstantsObject, is_in: str = ''
        ) -> None:
    groups_bin = zeros((len(samples), constants.N_CABS), dtype = int8)

    # iterate over the group cabs to retrieve their indexes
    for i, sample in enumerate(samples):
        for cab in sample:
            groups_bin[i, constants.INVERTED_CABS_DICT[cab]] = 1
    groups_bin = csr_matrix(groups_bin)

    save_sparse_csr(
            USER_DFS_DIR
            + str(target) + '_'
            + str(group_size) + '_'
            + str(inside)
            + is_in,
            groups_bin
            )


# load the groups from binary matrices into a list of cabs
# TODO: Fix?
def load_groups(
        constants: ConstantsObject, target: str, group_size: int, inside: str
        ) -> List[str]:

    groups_bin = load_sparse_csr(
            USER_DFS_DIR
            + str(target) + '_'
            + str(group_size) + '_'
            + str(inside) + '.npz'
            ).toarray()

    cabs_list = []
    for i in range(0, groups_bin.shape[0]):
        tmp = groups_bin[i, :]
        indexes = where(tmp == 1)[0]

        tmp_list = [constants.CABS_DICT[index] for index in indexes]
        cabs_list.append(tmp_list)

    return cabs_list


def attack_cabs():
    group_1 = read_pickle(MOBILITY_CABS_DIR + 'group1.pkl').target.tolist()
    group_2 = read_pickle(MOBILITY_CABS_DIR + 'group2.pkl').target.tolist()
    group_3 = read_pickle(MOBILITY_CABS_DIR + 'group3.pkl').target.tolist()
    return group_1 + group_2 + group_3


def get_cabs_dict(unique_indvs: List[str]) -> Dict[int, str]:
    return {key: indv for key, indv in enumerate(unique_indvs)}


# Returns the inversion of the given dictionary.
def get_inverted_dict(d: dict) -> dict:
    return {value: key for key, value in d.items()}


def get_ground_truth_matrix(
        n_cabs: int, n_rois: int, n_epochs: int, unique_indvs: List[str],
        inverted_cabs_dict: List[str]
        ):
    # create a 3d matrix containing the ground truth of all individuals.
    ground_truth = zeros((n_cabs, n_rois, n_epochs), dtype = int)
    for cab in unique_indvs:
        index = inverted_cabs_dict[cab]
        ground_truth[index] = load_sparse_csr(GROUND_TRUTH_DIR
                + str(cab) + '.npz').toarray()

        return ground_truth


def get_lcols(n_rois: int) -> List[str]:
    return ['l' + str(i) for i in range(0, n_rois)]


def get_feature_cols(n_rois: int) -> List[str]:
    feats_cols = []
    for i in range(0, n_rois):
        feats_cols.append('l' + str(i) + '__variance')
        feats_cols.append('l' + str(i) + '__minimum')
        feats_cols.append('l' + str(i) + '__median')
        feats_cols.append('l' + str(i) + '__maximum')
        feats_cols.append('l' + str(i) + '__length')
        feats_cols.append('l' + str(i) + '__mean')
        feats_cols.append('l' + str(i) + '__standard_deviation')
        feats_cols.append('l' + str(i) + '__sum_values')

    return feats_cols


# Create an object initialized with constants needed for our program.
def constants_object() -> ConstantsObject:
    # Setup constants.
    #CABS = read_pickle(CABS_FILE).target.tolist()
    CABS = read_pickle(CABS_FILE).target.tolist()
    N_CABS = len(CABS)

    CABS_DICT = get_cabs_dict(CABS)
    INVERTED_CABS_DICT = get_inverted_dict(CABS_DICT)

    GROUND_TRUTH = get_ground_truth_matrix(
            N_CABS, N_ROIS, N_EPOCHS, CABS, INVERTED_CABS_DICT
            )
    LCOLS = get_lcols(N_ROIS)
    FEATS_COLS = get_feature_cols(N_ROIS)
    COLS = FEATS_COLS + ["is_train", "is_in_the_data"]

    GROUP_LOCKS = {group_size: RWLock() for group_size in GROUP_SIZES}
    TARGET_LOCKS = {
            target: {group_size: Lock() for group_size in GROUP_SIZES}
            for target in CABS
            }

    return ConstantsObject(
            CABS, FEATS_COLS, COLS, DATA_SIZE, N_FEATURES, GROUND_TRUTH,
            INVERTED_CABS_DICT, LCOLS, GROUP_LOCKS, TARGET_LOCKS, N_CABS
            )

