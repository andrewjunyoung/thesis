from numpy import load, zeros, where, int, float32, vstack
from pandas import DataFrame, Series
from scipy.sparse import lil_matrix
from random import sample

# ts fresh for time series feature extraction
from tsfresh.feature_extraction import extract_features, MinimalFCParameters
from tsfresh.utilities.dataframe_functions import impute

# scikit learn modules
from sklearn.feature_selection import RFE
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Config and utils files
from src.settings.main import *
from utils import *

## Beg utility functions #####################################################


def extract_feats(agg, LCOLS, FEATS_COLS):
    # keep the aggregates of the first eek
    tr_agg = agg[:, 0: WEEKLY_EPOCHS]
    # create dataframes to give to tsfresh
    tr_df = DataFrame(tr_agg.T, columns=LCOLS)

    # create a column id for the feature extraction
    tr_df['id'] = 0
    tr_feat = extract_features(
            tr_df, column_id='id', n_jobs = 0,
            default_fc_parameters = MinimalFCParameters()
            )
    tr_feat = impute(tr_feat)
    tr_feat = tr_feat[FEATS_COLS]

    return tr_feat.values.ravel().tolist()


def get_features(constants, sample, isForTraing, hasTarget):
    agg = aggregate(
            sample, constants.GROUND_TRUTH, constants.INVERTED_CABS_DICT
            )
    feat = extract_feats(
            agg, constants.LCOLS, constants.FEATS_COLS
            )

    del agg

    mark_traing_as(isForTraining, hasTarget, feat)

    return feat


def sample_unique_groups(constants, cabs, target, group_size, DATA_SIZE, tra):
    groups_w = []
    # get the list ith groups containing the user
    while(len(groups_w) < (DATA_SIZE / 2.0)):
        group = sample_cabs_ith_target(cabs, target, group_size)
        groups_w.append(group)

    # save the groups to disk for future use
    save_groups(target, groups_w, group_size, train, constants, 'in')

    groups_wo = []
    # get the list ith groups not containing the user
    while(len(groups_wo) < (DATA_SIZE / 2.0)):
        group = sample_cabs_no_target(cabs, target, group_size)
        groups_wo.append(group)

    # save the groups to disk for future use
    save_groups(target, groups_wo, group_size, train, constants, 'out')

    return groups_w, groups_wo


def data_with_aggs(constants, groups, data, isTrainingData, hasTarget):
    for i, group in enumerate(groups):
        data[i, :] = get_features(
                constants, group, isTraingData, hasTarget
                )
    return data


def new_data():
    return zeros((TRAIN_DATA_SIZE // 2, len(constants.COLS)), dtype = float32)


def data_array(constants, cabs, DATA_SIZE, isTrainingData):
    if isTrainingData:
        tag = 'tr'
    else:
        tag = 'ts'

    gr_w, gr_wo = sample_unique_groups(
            constants, prior_cabs, target, group_size, DATA_SIZE, tag
            )

    data_w = data_with_aggs(constants, gr_w, new_data(), isTrainingData, True)
    data_wo = data_with_aggs(constants, gr_wo, new_data(), isTrainingData,
            False)

    return vstack((data_w, data_wo))


def user_data(constants, group_size, target, prior_cabs, non_prior_cabs):
    train_data_array = data_array(
            constants, prior_cabs, target, TRAIN_DATA_SIZE, True
            )
    test_data_array = data_array(
            constants, non_prior_cabs, target, TEST_DATA_SIZE, False
            )

    # Concatenate train and test data array.
    data_array = vstack((train_data_array, test_data_array))
    del train_data_array, test_data_array

    # The dataframe to store our traing / testing data.
    data = DataFrame(data_array, columns = constants.COLS)
    # OR: «data = nan_to_num(data_array)»

    file_path = USER_DFS_DIR + str(target) + '_' + str(group_size) + '.pkl'
    constants.TARGET_LOCKS[target][group_size].acquire()
    data.to_pickle(file_path)
    constants.TARGET_LOCKS[target][group_size].release()

    return data

####################################################### End utility functions ##
## Begin main method ###########################################################

if __name__ == "__main__":
    run_attack(user_data)

############################################################# End main method ##

