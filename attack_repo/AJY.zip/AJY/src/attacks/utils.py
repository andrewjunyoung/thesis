# -*- coding: utf-8 -*-

"""
Description: A series of utility functions to implement membership inference
(MI) attacks following the specification in Pyrgelis et al's 2017 paper "Knock
knock, who's there: Membership inference on aggregate location data".

Author: Andrew J. Young at Imperial College London.
"""

## Begin imports ###############################################################

# APIs
from os import path
from queue import Queue
from numpy import savez, float32, newaxis, arange, savez_compressed
from pandas import DataFrame, read_pickle, Series
from random import sample
from scipy.sparse import csr_matrix
from threading import Thread, Lock
from matplotlib.pyplot import cm, subplots, setp
from collections import namedtuple

# TSFresh for time series feature extraction.
from tsfresh.feature_extraction import extract_features, MinimalFCParameters
from tsfresh.utilities.dataframe_functions import impute

# Scikit learn module imports.
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (f1_score, precision_score, recall_score,
                             confusion_matrix, accuracy_score, roc_curve,
                             roc_auc_score, auc)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

# Relative file references
from setup_utils import *
from src.settings.main import *
# from src.defenses.low_count_suppression import is_low_count

################################################################# End imports ##
## Begin utility functions #####################################################

def mark_training_as(
        isForTraining: bool, hasTarget: bool, tr_feat: list
        ) -> None:
    if isForTraining:
        tr_feat.append(0.0)
    else:
        tr_feat.append(1.0)

    if hasTarget:
        tr_feat.append(0.0)
    else:
        tr_feat.append(1.0)


# aggregate the sampled cabs and return the corresponding matrix
def aggregate(SAMPLE: List[str], GROUND_TRUTH, INVERTED_CABS_DICT):
    agg_matrix = zeros((N_ROIS, N_EPOCHS), dtype=int)
    for indv in SAMPLE:
        agg_matrix = agg_matrix + GROUND_TRUTH[INVERTED_CABS_DICT[indv]]
    return agg_matrix


# Sample a number of cabs not including the target cab.
# Return the list of cab IDs.
def sample_cabs_no_target(
        SAMPLE: List[str], target: str, group_size: int
        ) -> List[str]:
    assert group_size < len(SAMPLE)

    target_cab = set([target])
    non_target_cabs = list(set(SAMPLE) - target_cab)
    sample_cabs = list(sample(non_target_cabs, group_size))

    return sorted(sample_cabs)


# Sample a number of cabs including the target cab.
# Return the list of cab IDs.
def sample_cabs_with_target(
        SAMPLE: List[str], target: str, group_size: int
        ) -> List[str]:
    assert group_size <= len(SAMPLE)

    target_cab = set([target])
    non_target_cabs = list(set(SAMPLE) - target_cab)
    sample_cabs = sample(non_target_cabs, group_size - 1)
    sample_cabs_with_target = list(set(sample_cabs) | target_cab)

    return sorted(sample_cabs_with_target)


# let's try new ways of extracting features
def extract_feats(
        agg: ndarray, LCOLS: List[str], FEATS_COLS: List[str]
        ) -> List[str]:
    feat_list = []
    for week in range(0, WEEKS_OF_DATA):
        new_agg = agg[:, week * WEEKLY_EPOCHS: (week + 1) * WEEKLY_EPOCHS]

        # Extract and impute features.
        df = DataFrame(new_agg.T, columns=LCOLS)
        df['id'] = 0
        # WARNING: TSFresh has known issues with multiprocessing.
        feats = extract_features(df, column_id='id', n_jobs=0,
                default_fc_parameters=MinimalFCParameters())
        feats = impute(feats)
        feats = feats[FEATS_COLS]

        # Convert this into a list.
        formatted_feats = feats.values.ravel().tolist()

        feat_list.append(formatted_feats)

    return feat_list


# Returns the extract features list for aggregates.
def get_features(
        constants: ConstantsObject, sample: List[str], target: str, group_size:
        int, hasTarget: bool
        ):
    agg = aggregate(
            sample, constants.GROUND_TRUTH, constants.INVERTED_CABS_DICT
            )

    if DEFENSES["Low count suppression"]:
        print("Low count suppression")
        print(agg)
        agg = suppress_low_counts(agg)
        print(agg)
    if DEFENSES["Add noise"]:
        print("Add noise")
        agg = add_noise(agg, group_size)

    feat_list = extract_feats(
            agg, constants.LCOLS, constants.FEATS_COLS
            )

    del agg

    # Mark whether this row is part of training or not.
    week = 0
    for feat in feat_list:
        mark_training_as((week <= N_WEEKS_TRAINING - 1), hasTarget, feat)
        week += 1

    return feat_list


# Train the classifier using the user data.
def train_model(
        target: str, group_size: int, cl, cl_name: str, train_data, train_labels
        ):
    # constants: (target, group_size, clf, name, X_train, y_train)
    clf = cl.fit(train_data, train_labels)
    print('Training classifier: ' + cl_name +
            '. Training accuracy:', clf.score(train_data, train_labels))
    return clf


# evaluate how the model performs
def test_model(
        target: str, group_size: int, model, cl_name: int, test_data,
        test_labels, GROUP_LOCKS: list
        ):
    # create a new df to store results
    DF_RES_COLS = ['cab', 'cl', 'tp', 'fp', 'fn', 'tn', 'acc', 'ppv', 'tpr',
                   'fpr', 'auc', 'f1']

    # if there is a file for the users
    if path.isfile(RESULTS_DIR + 'res_' + str(group_size) + '.pkl'):
        GROUP_LOCKS[group_size].r_acquire()
        res = read_pickle(RESULTS_DIR + 'res_' + str(group_size) + '.pkl')
        GROUP_LOCKS[group_size].r_release()
    else:
        res = DataFrame(columns=DF_RES_COLS)

    # make predictions with the trained model
    preds = model.predict(test_data)
    print('Training classifier: ' + cl_name +
            '. Testing accuracy:', model.score(test_data, test_labels))

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    # print precision and recall
    conf = confusion_matrix(test_labels, preds, labels=[0.0, 1.0])
    acc = accuracy_score(test_labels, preds)
    ppv = precision_score(test_labels, preds, pos_label=0.0)
    rec = recall_score(test_labels, preds, pos_label=0.0)
    tnr = recall_score(test_labels, preds, pos_label=1.0)
    f1 = f1_score(test_labels, preds, pos_label=0.0)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thresholds = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(
            Series(
                [target, cl_name, conf[0][0], conf[1][0], conf[0][1],
                    conf[1][1], acc, ppv, rec, 1.0 - tnr, area, f1],
                index=DF_RES_COLS
                ),
            ignore_index=True
        )

    # save the new pickle to disk
    file_path = RESULTS_DIR + 'res_' + str(group_size) + '.pkl'
    GROUP_LOCKS[group_size].w_acquire()
    res.to_pickle(file_path)
    GROUP_LOCKS[group_size].w_release()


def scale_data(x_train, x_test):
    scaler = StandardScaler()
    scaler.fit(x_train)
    x_train = scaler.transform(x_train)
    x_test = scaler.transform(x_test)
    return x_train, x_test


# Des dimensionality reduction.
def reduce_dimensionality(x_train, x_test):
    # reduce the dataset dimensions from 101 * 168 = 16,968 to 500 principal components
    # (potentially less components are sufficient for the attack)
    pca = PCA(n_components= tr_data_size / 4, svd_solver='randomized', random_state=42)
    pca.fit(train_data)

    x_train = pca.transform(x_train)
    x_test = pca.transform(x_test)

    return x_train, x_test


def attack_user(
        user_data_fn, constants, group_size, target, prior_cabs, non_prior_cabs
        ):
    # If there is a dataset for the target user then load it, else create it.
    file_path = USER_DFS_DIR + str(target) + '_' + str(group_size) + '.pkl'
    if path.isfile(file_path):
        constants.TARGET_LOCKS[target][group_size].acquire()
        data = read_pickle(file_path)
        constants.TARGET_LOCKS[target][group_size].release()
    else:
        data = user_data_fn(
                constants, group_size, target, prior_cabs, non_prior_cabs
                )

    # Define the columns of features.
    features = data.columns[:constants.N_FEATURES]

    # Split the data to train and test parts.
    x_train = data[data['is_train'] == 0.0]
    x_test = data[data['is_train'] == 1.0]

    # Get the labels.
    y_train = x_train['is_in_the_data']
    y_test = x_test['is_in_the_data']

    # Keep only the features.
    x_train = x_train[features]
    x_test = x_test[features]

    # Do feature elimination with RFE.
    sel = feature_selection(x_train, y_train)

    x_train = sel.transform(x_train)
    x_test = sel.transform(x_test)

    # define the classifiers and their parameters
    CLASSIFIERS = [
            LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42),
            KNeighborsClassifier(5),
            RandomForestClassifier(max_depth=10, n_estimators=30, n_jobs=-1, random_state=42),
            MLPClassifier(solver='adam', hidden_layer_sizes=(200), random_state=42)
            ]

    # Create 4 threads -- one for each classifier -- and run them in parallel.
    for classifier_name, classifier in zip(CLASSIFIER_NAMES, CLASSIFIERS):
        if classifier_name == "MLP":
            x_train, x_test = scale_data(x_train, x_test)

        model = train_model(
                target, group_size, classifier, classifier_name, x_train,
                y_train
                )
        test_model(
                target, group_size, classifier, classifier_name, x_test,
                y_test, constants.GROUP_LOCKS
                )


def feature_selection(train_data, train_labels):
    # estimator = RandomForestClassifier(n_estimators=30, n_jobs=-1, random_state=42)
    estimator = LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42)

    # Do recursive feature elimination to keep some number of features (as the
    # training dataset size)
    selector = RFE(estimator, n_features_to_select=300, step=50)
    selector = selector.fit(train_data, train_labels)

    print('# of features:', selector.n_features_)
    return selector


# Define a thread class which will allow attacks to be parallelized.
class AttackWorker(Thread):
    def __init__(
            self, constants: ConstantsObject, queue: Queue, user_data_fn: Any,
            prior_cabs, non_prior_cabs
            ):
        super(AttackWorker, self).__init__()
        self.constants = constants
        self.queue = queue
        self.user_data_fn = user_data_fn
        self.prior_cabs = prior_cabs
        self.non_prior_cabs = non_prior_cabs

    def run(self):
        queue = self.queue
        while True:
            job = queue.get()
            target = job.target
            group_size = job.group_size
            attack_user(
                    self.user_data_fn, self.constants, group_size, target,
                    self.prior_cabs, self.non_prior_cabs
                    )
            queue.task_done()



TargetAndGroupSize = namedtuple('TargetAndGroupSize', 'target group_size')


def run_attack(user_data_fn) -> None:
    # Create an object to pass around constants.
    constants = constants_object()
    ATTACK_CABS = attack_cabs()

    ## Begin subset MI attack variables ########################################
    # This section is only needed for subset MI attacks.

    prior_cabs = sample(constants.CABS, int(SUBSET_SIZE * N_INDVS))
    non_prior_cabs = list(set(constants.CABS) - set(prior_cabs))

    ########################################## End subset MI attack variables ##

    queue = Queue()
    for target in ATTACK_CABS:
        for group_size in GROUP_SIZES:
            queue.put(TargetAndGroupSize(target, group_size))

    for t in range(N_THREADS):
        worker = AttackWorker(
                constants, queue, user_data_fn, prior_cabs, non_prior_cabs
                )
        worker.daemon = True
        worker.start()

    queue.join()
    print("Attack complete. Exiting.")

####################################################### End utility functions ##

