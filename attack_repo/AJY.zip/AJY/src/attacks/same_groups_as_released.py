from utils import *
from src.settings.main import *
from numpy import savez, float32, arange, zeros
from pandas import DataFrame

## Begin utility functions #####################################################

def user_data(
        constants, group_size, target, prior_cabs=None, non_prior_cabs=None
        ):
    print("user_data")
    # Fill the data with aggregate instances including the user.
    # This looks ugly, but it's optimized to not need to use vstack.
    data_array = zeros((DATA_SIZE, len(constants.COLS)), dtype = float32)
    for i in range(0, DATA_SIZE, 6):
        # First with aggregate instances that include the target.
        sample_w = sample_cabs_with_target(constants.CABS, target, group_size)
        tr1_w_data, tr2_w_data, ts_w_data = get_features(
                constants, sample_w, target, group_size, True
                )
        data_array[i, :] = tr1_w_data
        data_array[i + 1, :] = tr2_w_data
        data_array[i + 2, :] = ts_w_data

        # Then with aggregate instances NOT including the target.
        sample_wo = sample_cabs_no_target(constants.CABS, target, group_size)
        tr1_wo_data, tr2_wo_data, ts_wo_data = get_features(
                constants, sample_wo, target, group_size, False
                )
        data_array[i + 3, :] = tr1_wo_data
        data_array[i + 4, :] = tr2_wo_data
        data_array[i + 5, :] = ts_wo_data

    # The dataframe to store our training / testing data.
    data = DataFrame(data_array, columns = constants.COLS)

    file_path = USER_DFS_DIR + str(target) + '_' + str(group_size) + '.pkl'
    constants.TARGET_LOCKS[target][group_size].acquire()
    data.to_pickle(file_path)
    constants.TARGET_LOCKS[target][group_size].release()

    return data


####################################################### End utility functions ##
## Begin main method ###########################################################

if __name__== '__main__':
    run_attack(user_data)

############################################################# End main method ##

