import os
import pandas as pd
import numpy as np
import sys
from numpy import ndarray, random, zeros
import pickle
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from random import sample

# scikit learn modules
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, roc_auc_score, auc
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from multiprocessing import Pool

from utils import *
from threading import Lock
from src.settings.main import *
from src.defenses.output_noise_addition import add_noise, scale_factor
from src.utils.rw_lock import RWLock
from src.utils.rm_rf import remove_files
from src.defenses.low_count_suppression import suppress_low_counts


# -------------- Utility Functions --------------- #

# save the group list to a 2 dimensional matrix each row is a group each column
def save_groups(target, groups, group_size, train, inside):
    groups_bin = np.zeros( (len(groups), n_cabs) , dtype = np.int8)
    # iterate over the group cabs to retrieve their indexes
    for i, group in enumerate(groups):
        for cab in group:
            groups_bin[i, inv_cabs_dict[cab]] = 1

    groups_bin = csr_matrix(groups_bin)

    save_sparse_csr(USER_DFS_DIR + str(target) + '_' + str(group_size) + '_' + str(train) + '_' + str(inside), groups_bin)

# return a list of lists where each item is a group to aggregate
def sample_unique_groups(cabs, target_cab, group_size, data_size, train):
    groups_in = []
    groups_out = []

    # fill the list with groups containing the user
    while( len(groups_in) < (data_size // 2.0) ):
        group = sample_cabs_with_target(cabs, target_cab, group_size)
        groups_in.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_in, group_size, train, 'in')

    # fill the list with groups not containing the user
    while( len(groups_out) < (data_size // 2.0) ):
        group = sample_cabs_no_target(cabs, target_cab, group_size)
        groups_out.append(group)

    # save the groups to disk for future use
    save_groups(target_cab, groups_out, group_size, train, 'out')

    return groups_in, groups_out

# aggregate the sampled cabs and return the corresponding matrix
def aggregate(cabs):
    # the aggregation matrix
    agg = np.zeros((N_ROIS, WEEKLY_EPOCHS) , dtype = np.int16())
    for cab in cabs:
        agg = agg + ground_truth[inv_cabs_dict[cab]]
    return agg

# just serialize the aggregates
def extract_feats(agg: ndarray) -> ndarray:
    return agg.ravel().tolist()

def get_features(group, isForTraining, hasTarget):
    agg = aggregate(group)

    if DEFENSES["Low count suppression"]:
        agg = suppress_low_counts(agg, DEFENSES["Low count suppression"])
    if DEFENSES["Add noise"]:
        agg = add_noise(agg, DEFENSES["Add noise"], group_size)

    tr_feat = extract_feats(agg)

    del agg

    mark_training_as(isForTraining, hasTarget, tr_feat)

    return tr_feat

# create a dataset for the target user
def user_data(
        unique_cabs, prior_cabs, target, group_size, cols, TRAIN_DATA_SIZE,
        TEST_DATA_SIZE
        ):
    # sample groups from the prior knowledge list to train the classifier
    tr_gr_in, tr_gr_out = sample_unique_groups(prior_cabs, target, group_size, TRAIN_DATA_SIZE, 'tr')

    # first create a dataset for the target user
    tr_data_in = np.zeros((TRAIN_DATA_SIZE // 2, len(cols)), dtype = np.int16)
    tr_data_out = np.zeros((TRAIN_DATA_SIZE // 2, len(cols)), dtype = np.int16)

    # fill the data with aggregate instances including the user
    for i, j in enumerate(tr_gr_in):
        tr_w_data = get_features(j, True, True)
        if tr_w_data is None:
            break
        tr_data_in[i, :] = tr_w_data
        del tr_w_data

    # then with aggregate instances NOT including the user
    for i, j in enumerate(tr_gr_out):
        tr_wo_data = get_features(j, True, False)
        if tr_wo_data is None:
            break
        tr_data_out[i, :] = tr_wo_data
        del tr_wo_data

    train_data_array = np.vstack((tr_data_in, tr_data_out))
    del tr_gr_in, tr_gr_out
    del tr_data_in, tr_data_out

    # sample groups for testing - sample from the whole list of cabs
    ts_gr_in, ts_gr_out = sample_unique_groups(unique_cabs, target, group_size, TEST_DATA_SIZE, 'ts')

    ts_data_in = np.zeros((TEST_DATA_SIZE // 2, len(cols)), dtype = np.int16)
    ts_data_out = np.zeros((TEST_DATA_SIZE // 2, len(cols)), dtype = np.int16)

    for i, j in enumerate(ts_gr_in):
        ts_w_data = get_features(j, False, True)
        ts_data_in[i, :] = ts_w_data
        del ts_w_data

    for i, j in enumerate(ts_gr_out):
        ts_wo_data = get_features(j, False, False)
        ts_data_out[i, :] = ts_wo_data
        del ts_wo_data

    # concat test data in and out
    test_data_array = np.vstack((ts_data_in, ts_data_out))
    del ts_gr_in, ts_gr_out
    del ts_data_in, ts_data_out

    # finally concat train and test data array
    data_array = np.vstack((train_data_array, test_data_array))
    del train_data_array, test_data_array

    data = np.nan_to_num(data_array)

    # save the dataset for future use
    TARGET_LOCKS[target][group_size].acquire()
    np.savez(USER_DFS_DIR + str(target) + '_' + str(group_size) + '.npz', data)
    TARGET_LOCKS[target][group_size].release()

def dim_reduction(train_data):
    # reduce the dataset dimensions from 101 * 168 = 16,968 to 500 principal components
    # (potentially less components are sufficient for the attack)
    pca = PCA(n_components= TRAIN_DATA_SIZE // 4, svd_solver='randomized', random_state=42)
    pca.fit(train_data)
    return pca

# evaluate how the model performs
def test_model(target, group_size, model, cl_name, test_data, test_labels):
    # create a new df to store results
    df_res_cols = ['cab', 'cl', 'auc']

    # if there is a file for the users
    if os.path.isfile(RESULTS_DIR + 'res_' + str(group_size) + '.pkl') == True:
        res = pd.read_pickle(RESULTS_DIR + 'res_' + str(group_size) + '.pkl')
    else:
        res = pd.DataFrame(columns = df_res_cols)

    # get the scores for each item in testing (used to calculate roc auc score)
    scores = model.predict_proba(test_data)

    # calculate fpr, tpr and auc for ROC curve plot
    fpr, tpr, thresholds = roc_curve(test_labels, scores[:, 0], pos_label=0)
    area = auc(fpr, tpr)

    # dataframe to store the results of the target user
    res = res.append(pd.Series([target, cl_name, area], index = df_res_cols), ignore_index=True)

    # save the new pickle to disk
    res.to_pickle(RESULTS_DIR + 'res_' + str(group_size) + '.pkl')

# attack the target user
def attack_user(
        target, group_size, cols, TRAIN_DATA_SIZE, TEST_DATA_SIZE, N_FEATURES
        ):
    # create a dataset for the user
    try:
        TARGET_LOCKS[target][group_size].acquire()
        data = np.load(USER_DFS_DIR + str(target) + '_' + str(group_size) + '.npz')
        TARGET_LOCKS[target][group_size].release()

        data = data['arr_0']
    except:
        FAILED_TARGETS.append(target)
        print(target)
        return

    # the dataframe to store our training // testing data
    data = pd.DataFrame(data, columns=cols)

    # define the columns of features
    features = data.columns[:N_FEATURES]

    # split the data to train and test parts
    X_train = data[data['is_train'] == 0.0]

    # get the train labels
    y_train = X_train['is_in_the_data']

    # keep only the features
    X_train = X_train[features]

    # define the testing set and repeat testing 100 times
    X_test = data[data['is_train'] == 1.0]

    # get the test labels
    y_test = X_test['is_in_the_data']

    # keep only the features
    X_test = X_test[features]

    # scale the data before PCA
    scaler = StandardScaler()
    scaler.fit(X_train)
    X_train = scaler.transform(X_train)
    X_test = scaler.transform(X_test)

    # do dimensionality reduction with PCA
    sel = dim_reduction(X_train)
    X_train = sel.transform(X_train)
    X_test = sel.transform(X_test)

    print(X_train.shape)
    print(X_test.shape)

    #np.savez(USER_DFS_DIR + str(target) + '_components.npz', sel.components_)
    #np.savez(
    #        USER_DFS_DIR + str(target) + '_explained_variance.npz',
    #        sel.explained_variance_ratio_
    #        )

    # classifier names
    names = ["LR", "KNN", "RF", "MLP"]

    # define the classifiers and their parameters
    classifiers = [
            LogisticRegression(solver='liblinear', n_jobs=-1, random_state=42),
            KNeighborsClassifier(5),
            RandomForestClassifier(max_depth=10, n_estimators=30, n_jobs=-1, random_state=42),
            MLPClassifier(solver='adam', hidden_layer_sizes=(200), random_state=42)
            ]

    # train and test various classifiers
    for name, clf in zip(names, classifiers):
        md = train_model(target, group_size, clf, name, X_train, y_train)
        test_model(target, group_size, md, name, X_test, y_test)

def attack_data(users, group_size):
    for target in users:
        print('Target:', target)
        prior_cabs = sample(unique_cabs, int(N_INDVS * 0.2))

        neg_prior_cabs = set(unique_cabs) - set(prior_cabs)
        neg_prior_cabs = list(neg_prior_cabs)

        user_data(neg_prior_cabs, prior_cabs, target, group_size, cols, TRAIN_DATA_SIZE, TEST_DATA_SIZE)

## Begin constants #############################################################

# list of cab identifiers
unique_cabs = pd.read_pickle(TARGETS_FILE).target.tolist()

# number of cabs
n_cabs = len(unique_cabs)

# Load the 3 groups of cabs we want to attack.
gr1 = pd.read_pickle(MOBILITY_CABS_DIR + 'group1.pkl').target.tolist()
gr2 = pd.read_pickle(MOBILITY_CABS_DIR + 'group2.pkl').target.tolist()
gr3 = pd.read_pickle(MOBILITY_CABS_DIR + 'group3.pkl').target.tolist()

# the final list of attack cabs
attack_cabs = gr1 + gr2 + gr3

cabs_dict = dict()

# create a dictionary in the form of id:cab_name
for k, cab in enumerate(unique_cabs):
    cabs_dict[k] = cab

# invert the above dictionary in the form of cab_name:id
inv_cabs_dict = {v: k for k, v in cabs_dict.items()}
# create a 3d matrix containing the ground truth of all cabs
ground_truth = np.zeros((n_cabs, N_ROIS, WEEKLY_EPOCHS), dtype = np.int8)

# load the ground truth of each cab to the matrix
# the ground_truth of each cab is a binary matrix of size (n_locations, n_timeslots), where each
# item (i, j) is 1 if the user visited the location i at time j
for cab in unique_cabs:
    ground_truth[inv_cabs_dict[cab]] = load_sparse_csr(GROUND_TRUTH_DIR + str(cab) + '.npz').toarray()[:, 0 * WEEKLY_EPOCHS:1 * WEEKLY_EPOCHS]

# columns for the features dataframes
lcols = []
for i in range(0, N_ROIS):
    for j in range(0, WEEKLY_EPOCHS):
        lcols.append('l' + str(i) + 't' + str(j))

# how many features we have
N_FEATURES = N_ROIS * WEEKLY_EPOCHS

# the feature columns
cols = lcols + ['is_train', 'is_in_the_data']

FAILED_TARGETS: list = []

TARGET_LOCKS = {
        target: {group_size: Lock() for group_size in GROUP_SIZES}
        for target in attack_cabs
        }

############################################################### End constants ##
## Begin main ##################################################################

# parallelize the generation of aggregates for the users
for group_size in GROUP_SIZES:
    for l in range(0, len(attack_cabs), N_PROCESSES):
        attack_batches = [[x] for x in attack_cabs[l:l+N_PROCESSES]]

        p = Pool(N_PROCESSES)
        p.starmap(
                attack_data,
                [(attack_batch, group_size) for attack_batch in attack_batches],
                chunksize=1
                )
        p.close()
        p.join()

    for target in attack_cabs:
        attack_user(
                target, group_size, cols, TRAIN_DATA_SIZE, TEST_DATA_SIZE,
                N_FEATURES
                )

    print("Clearing folder contents of" + str(USER_DFS_DIR))
    remove_files(USER_DFS_DIR)

print(
        "Failed " +
        str(len(FAILED_TARGETS)) +
        " targets.\nList: " +
        str(FAILED_TARGETS)
        )

#################################################################### End main ##
