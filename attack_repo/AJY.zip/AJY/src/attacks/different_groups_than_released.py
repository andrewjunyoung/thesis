from numpy import zeros, float32, vstack
from utils import *
from src.settings.main import *

## Begin utility functions #####################################################

# return a list of lists where each item is a group to aggregate
def sample_unique_groups(target, group_size, constants):
    if path.isfile(
            USER_DFS_DIR + str(target) + '_' + str(group_size) + '_in' + '.npz'
            ):
        print('Loading files of unique groups...')
        groups_w_target = load_groups(constants, target, group_size, 'in')
        groups_wo_target = load_groups(constants, target, group_size, 'out')
    else:
        groups_w_target = []
        while(len(groups_w_target) < (DATA_SIZE // 2)):
            group = sample_cabs_with_target(constants.CABS, target, group_size)
            if group not in groups_w_target:
                groups_w_target.append(group)

        groups_wo_target = []
        while(len(groups_wo_target) < (DATA_SIZE // 2)):
            group = sample_cabs_no_target(constants.CABS, target, group_size)
            if group not in groups_wo_target:
                groups_wo_target.append(group)

    return groups_w_target, groups_wo_target


def extract_feats(agg, LCOLS, FEATS_COLS, week):
    # keep the aggregates of a specific week
    tr_agg = agg[:, week * WEEKLY_EPOCHS: (week + 1) * WEEKLY_EPOCHS]
    # create dataframes to give to tsfresh
    tr_df = DataFrame(tr_agg.T, columns=LCOLS)

    # create a column id for the feature extraction
    tr_df['id'] = 0
    tr_feat = extract_features(
            tr_df, column_id='id', n_jobs = 0,
            default_fc_parameters = MinimalFCParameters()
            )

    # impute the features
    tr_feat = impute(tr_feat)
    tr_feat = tr_feat[FEATS_COLS]

    return tr_feat.values.ravel().tolist()


def get_features(constants, group, week, hasTarget):
    aggr = aggregate(group, constants.GROUND_TRUTH, constants.INVERTED_CABS_DICT)
    tr_feat = extract_feats(aggr, constants.LCOLS, constants.FEATS_COLS, week)
    if week == 2.0:
        tr_feat.append(1.0)
    else:
        tr_feat.append(0.0)

    # append whether the target user is in the dataset or not - 0.0 --> yes
    if hasTarget:
        tr_feat.append(0.0)
    else:
        tr_feat.append(1.0)

    return tr_feat

# create data for the user
def user_data(
        constants, group_size, target, prior_cabs = None, non_prior_cabs = None
        ):
    # sample the unique groups containing and not the user
    gr_in, gr_out = sample_unique_groups(
            target, group_size, constants
            )

    # first create a dataset for the target user
    data_in = zeros((DATA_SIZE // 2, len(constants.COLS)), dtype=float32)
    data_out = zeros((DATA_SIZE // 2, len(constants.COLS)), dtype=float32)

    week = 0
    # fill the data with aggregate instances including the user
    for i, group in enumerate(gr_in):
        # for each user group extract features from a different week
        w = week % 3
        # first with aggregate instances that include the user
        tr_w_data = get_features(constants, group, w, True)
        data_in[i, :] = tr_w_data
        week += 1

    week = 0
    for i, group in enumerate(gr_out):
        # for each user group extract features from a different week
        w = week % 3
        # then with aggregate instances NOT including the user
        tr_wo_data = get_features(constants, group, w, False)
        data_out[i, :] = tr_wo_data
        week += 1

    data_array = vstack((data_in, data_out))

    data = DataFrame(data_array, columns = constants.COLS)

    file_path = USER_DFS_DIR + str(target) + '_' + str(group_size) + '.pkl'
    constants.TARGET_LOCKS[target][group_size].acquire()
    data.to_pickle(file_path)
    constants.TARGET_LOCKS[target][group_size].release()

    return data

####################################################### End utility functions ##
## Begin main method ###########################################################

if __name__== '__main__':
    run_attack(user_data)

############################################################# End main method ##

