# -*- coding: utf-8 -*-

"""
Description: A class to implement read-write locks on top of the standard
threading library.  This is implemented with two mutexes (threading.Lock
instances) as per this wikipedia pseudocode:
https://en.wikipedia.org/wiki/Readers%E2%80%93writer_lock#Using_two_mutexes
Author: Tyler Neylon at Unbox Research.
"""

## Begin imports ###############################################################

from contextlib import contextmanager
from threading  import Lock

################################################################# End imports ##
## Begin class #################################################################


class RWLock(object):
    """
    RWLock class; this is meant to allow an object to be read from by multiple
    threads, but only written to by a single thread at a time. See:
    https://en.wikipedia.org/wiki/Readers%E2%80%93writer_lock

    Usage:

        from rwlock import RWLock

        my_obj_rwlock = RWLock()

        # When reading from my_obj:
        with my_obj_rwlock.r_locked():
            do_read_only_things_with(my_obj)

        # When writing to my_obj:
        with my_obj_rwlock.w_locked():
            mutate(my_obj)
    """

    def __init__(self):
        self.w_lock = Lock()
        self.num_r_lock = Lock()
        self.num_r = 0

    ## Begin reading methods ###################################################

    def r_acquire(self):
        self.num_r_lock.acquire()
        self.num_r += 1
        if self.num_r == 1:
            self.w_lock.acquire()
        self.num_r_lock.release()

    def r_release(self):
        assert self.num_r > 0
        self.num_r_lock.acquire()
        self.num_r -= 1
        if self.num_r == 0:
            self.w_lock.release()
        self.num_r_lock.release()

    @contextmanager
    def r_locked(self):
        """ This method is designed to be used via the `with` statement. """
        self.r_acquire()
        yield
        self.r_release()

    ##################################################### End reading methods ##
    ## Begin writing methods ###################################################

    def w_acquire(self):
        self.w_lock.acquire()

    def w_release(self):
        self.w_lock.release()

    @contextmanager
    def w_locked(self):
        """ This method is designed to be used via the `with` statement. """
        self.w_acquire()
        yield
        self.w_release()

    ##################################################### End writing methods ##
################################################################### End class ##
