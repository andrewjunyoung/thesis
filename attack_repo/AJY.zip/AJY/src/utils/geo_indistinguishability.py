"""
Author: OPAL-Compute

URL: https://github.com/OPAL-Project/OPAL-Compute/blob/master/src/baseFiles/main.py
"""

from __future__ import division, print_function
import multiprocessing
import math
import json
import random
import csv
import os
import datetime
import asyncio
from scipy.special import lambertw
from scipy.spatial import KDTree
import hashlib
import shutil
import time
import string


printable_chars = set(string.printable)


#--------------------- Privacy functions -----------------------------#

class PlanarLaplaceNoise(object):
    """Planar Laplace Noise class.
    epsilon: epsilon for noise addition
    id2latlong: dictionary with key as antenna_id and value as dict of
        'lat' and 'lon'
    """

    def __init__(self, epsilon, id2latlong):
        """Initialize noise addition class."""
        self.epsilon = epsilon
        self.id2latlong = id2latlong
        self.earth_radius = 6378.137  # const, in kilometers
        self.shared_salt = "ab43"
        self.earth_e2 = 0.00669437999014  # WGS-84 eccentricity squared
        self._init_antenna_preprocessing()

    def geodetic_in_ecef(self, lat, lon):
        """Convert geodetic coordinate to ecef format."""
        lat_r = self._deg2rad(lat)
        lon_r = self._deg2rad(lon)
        normal = self.earth_radius / (
            math.sqrt(1 - self.earth_e2 * (math.sin(lat_r) ** 2)))

        x = normal * math.cos(lat_r) * math.cos(lon_r)
        y = normal * math.cos(lat_r) * math.sin(lon_r)
        z = normal * (1 - self.earth_e2) * math.sin(lat_r)
        return [x, y, z]

    def _init_antenna_preprocessing(self):
        """Do antenna preprocessing to speed up the lookup from lat, lon."""
        list_points = []
        self.ind2id = {}
        i = 0
        for k, v in self.id2latlong.items():
            list_points.append(self.geodetic_in_ecef(v[0], v[1]))
            self.ind2id[i] = k
            i += 1
        self.antenna_tree = KDTree(list_points)

    def _get_nearby_antenna(self, lat, lon):
        """Return nearby antenna based on lat and lon."""
        return self.ind2id[self.antenna_tree.query(
            self.geodetic_in_ecef(lat, lon))[1]]

    def _deg2rad(self, deg):
        """Convert degree to radians."""
        return deg * (math.pi / 180)

    def _rad2deg(self, rad):
        """Convert radians to degree."""
        return rad * (180 / math.pi)

    def _inverse_cumulative_gamma(self, z):
        """Return radius in which the noisy position lies."""
        x = (z - 1) / math.e
        return -1 * (lambertw(x, k=-1).real + 1) / self.epsilon

    def _get_antenna_noised(self, antenna_id, theta, distance):
        """Return noised antenna id."""
        ang_distance = distance / self.earth_radius
        # print(theta, distance)
        lat = self._deg2rad(self.id2latlong[antenna_id][0])
        lon = self._deg2rad(self.id2latlong[antenna_id][1])
        mod_lat = math.asin(math.sin(lat) * math.cos(ang_distance) +
                            math.cos(lat) * math.sin(ang_distance) *
                            math.cos(theta))
        mod_lon = lon + math.atan2(
            math.sin(theta) * math.sin(ang_distance) * math.cos(lat),
            math.cos(ang_distance) - math.sin(lat) * math.sin(mod_lat))
        mod_lon = (mod_lon + 3 * math.pi) % (2 * math.pi) - math.pi

        # print(lat, lon, mod_lat, mod_lon)
        mod_lat = self._rad2deg(mod_lat)
        mod_lon = self._rad2deg(mod_lon)
        mod_antenna_id = self._get_nearby_antenna(mod_lat, mod_lon)
        return mod_antenna_id

    def __call__(self, antenna_id, username, event_time):
        """Return obfuscated antenna id after noise addition."""
        seed = str(antenna_id) + str(username) + str(event_time) \
               + self.shared_salt
        random.seed(seed)
        theta = random.random() * math.pi * 2
        z = random.random()
        r = self._inverse_cumulative_gamma(z)
        return self._get_antenna_noised(antenna_id, theta, r)


#--------------------- Utility functions -----------------------------#


def get_utf8_string(val):
    """Get utf8 string."""
    if isinstance(val, bytes):
        return val.decode('utf-8').strip()
    elif isinstance(val, datetime.datetime):
        return val.strftime('%Y-%m-%d %H:%M:%S')
    elif isinstance(val, str):
        return filter(lambda x: x in printable_chars, val.strip())
    return val


def get_salt(len):
    """Return a random salt of given length."""
    ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    chars = [random.choice(ALPHABET) for i in range(len)]
    return "".join(chars)


def get_chunks(users, batch_size):
    """Return chunks of list of users.
    Ensure each chunk is of batch_size at max or less.
    """
    chunks = []
    num_chunks = int(math.ceil((len(users) * 1.0) / batch_size))
    total_users = len(users)
    for i in range(num_chunks):
        chunks.append(
            users[i * batch_size:min(total_users, (i + 1) * batch_size)])
    return chunks


#--------------------- Database related functions --------------------#


def get_users_list_values_format(users_list):
    """Return users list in format required by SQL values."""
    return ','.join(['({})'.format(user) for user in users_list])


async def fetch_user_weights(connection, users_list):
    """Get user weights for the users in the list."""
    user2weights = {}
    async with connection.transaction():
        stmt = "SELECT id, weight FROM user2id_map WHERE id IN (VALUES {});". \
            format(get_users_list_values_format(users_list))
        async for record in connection.cursor(stmt):
            user2weights[record['id']] = record['weight']
    return user2weights


async def fetch_users(
    pool, start_date, end_date, random_seed, sample=1):
    """Fetch all the users and return sampled users using the sampling."""
    connection = await pool.acquire()
    all_users = []
    async with connection.transaction():
        await connection.execute("SELECT setseed({});".format(random_seed))
        stmt = await connection.prepare(
            """
            SELECT * FROM (SELECT DISTINCT(emiter_id) FROM public.opal as
            telecomdata WHERE telecomdata.event_time >= $1 and
            telecomdata.event_time <= $2) AS usersid ORDER BY random();
            """)
        async for record in stmt.cursor(start_date, end_date):
            all_users.append(record['emiter_id'])
    await pool.release(connection)
    required_num_users = int(math.ceil(len(all_users) * sample))
    required_users = all_users[:required_num_users]
    return required_users


async def fetch_data_async(pool, start_date, end_date, required_users, salt,
                           antenna_details, antenna_modifier):
    """Fetch data asynchronously."""
    conn = await pool.acquire()
    id2hash = {}
    antenna_id2uid = antenna_details['antenna_id2uid']
    uid2details = antenna_details['uid2details']

    def hash_user_id(user_id):
        """Hash id."""
        if user_id not in id2hash:
            id2hash[user_id] = hashlib.md5(
                (str(user_id) + salt).encode('utf-8')).hexdigest()
        return id2hash[user_id]

    def process_record(record):
        """Process record as per below rules.
        1. hash user_id and correspondent_id, use memoization
        2. modify antenna_id based on antenna2uid
        3. apply geoind if antenna_modifier present
        4. add lat, long, location_level_1 and location_level_2 based on uid
        """
        if record['antenna_id'] not in antenna_id2uid:
            return None
        record['user_id'] = hash_user_id(record['user_id'])
        record['correspondent_id'] = hash_user_id(
            record['correspondent_id'])
        record['antenna_id'] = antenna_id2uid[record['antenna_id']]
        if antenna_modifier:
            record['antenna_id'] = antenna_modifier(
                record['antenna_id'], record['user_id'], record['datetime'])
        record['latitude'] = uid2details[record['antenna_id']][0]
        record['longitude'] = uid2details[record['antenna_id']][1]
        record['location_level_1'] = uid2details[record['antenna_id']]['ll_1']
        record['location_level_2'] = uid2details[record['antenna_id']]['ll_2']
        return record

    stmt = await conn.prepare(
        """
        SELECT event_time as datetime, interaction_type as interaction,
        interaction_direction as direction, emiter_id as user_id,
        receiver_id as correspondent_id, telecomdata.antenna_id as antenna_id,
        duration as call_duration FROM public.opal as telecomdata
        WHERE telecomdata.event_time >= $1 and telecomdata.event_time <= $2
        AND telecomdata.emiter_id IN (VALUES {}) ORDER BY telecomdata.event_time;
        """.format(get_users_list_values_format(required_users)))
    user2data = {}
    data_col = [
        'interaction',
        'direction',
        'correspondent_id',
        'datetime',
        'call_duration',
        'antenna_id',
        'latitude',
        'longitude',
        'location_level_1',
        'location_level_2'
    ]
    async with conn.transaction():
        # Postgres requires non-scrollable cursors to be created
        # and used in a transaction.

        # Execute the prepared statement passing arguments
        # that will generate a series or records for the query.
        # Iterate over all of them and print every record.
        async for record in stmt.cursor(start_date, end_date):
            record = process_record(dict(record))
            if not record:
                continue
            username = str(record['user_id'])
            if username not in user2data:
                user2data[username] = [data_col]
            row_data = []
            for key in data_col:
                val = get_utf8_string(record[key])
                row_data.append(val)
            user2data[username].append(row_data)
    user2weights = await fetch_user_weights(conn, required_users)
    hasheduser2weights = {}
    for key, val in user2weights.items():
        hasheduser2weights[hash_user_id(key)] = val
    await pool.release(conn)
    return user2data, hasheduser2weights


async def fetch_antenna_details(pool):
    """Fetch antenna details."""
    connection = await pool.acquire()
    records_list = await connection.fetch(
        """
        SELECT id, latitude, longitude, location_level_1, location_level_2
        FROM antenna_records
        WHERE latitude != 0;
        """)
    latlong2uid = {}
    uid2details = {}
    antenna_id2uid = {}
    for record in records_list:
        latlong = (record['latitude'], record['longitude'])
        if latlong not in latlong2uid:
            latlong2uid[latlong] = '{}_{}'.format(
                record['latitude'], record['longitude'])
            uid2details[latlong2uid[latlong]] = {
                'lat': get_utf8_string(record['latitude']),
                'lon': get_utf8_string(record['longitude']),
                'll_1': get_utf8_string(record['location_level_1']),
                'll_2': get_utf8_string(record['location_level_2'])
            }
        antenna_id2uid[record['id']] = latlong2uid[latlong]
    await pool.release(connection)
    return {
        'antenna_id2uid': antenna_id2uid,
        'uid2details': uid2details
    }


async def fetch_country_code(pool):
    """Fetch country code for each user id.
    Not used right now.
    """
    connection = await pool.acquire()
    id2country = {}
    records_list = await connection.fetch(
        """SELECT id, country FROM user2id_map;""")
    for record in records_list:
        id2country[record['id']] = record['country']
    return id2country


def fetch_data(db, start_date, end_date, params, random_seed, data_dir, salt,
               epsilon, enable_geoind, max_users_per_fetch, dir_queue):
    """Fetch data in asynchronous fashion."""
    loop = asyncio.get_event_loop()
    pool = loop.run_until_complete(
        asyncpg.create_pool(db, min_size=5, max_size=5))

    required_users = loop.run_until_complete(fetch_users(
        pool, start_date, end_date, random_seed, params['sample']))
    # print("Total required users {}".format(required_users))

    antenna_details = loop.run_until_complete(
        fetch_antenna_details(pool))

    # ignoring max_users_per_fetch
    # batch_size = args.max_users_per_fetch if num_users <= \
    #     args.max_users_per_fetch else num_users // 2 + 1
    # batch_size = num_users + 1
    batch_size = max_users_per_fetch
    user_chunks = get_chunks(required_users, batch_size)

    antenna_modifier = None
    if enable_geoind:
        antenna_modifier = PlanarLaplaceNoise(
            epsilon, antenna_details['uid2details'])
    for required_users in user_chunks:
        while len(os.listdir(data_dir)) > 4:
            time.sleep(5)
        user2data, user2weights = loop.run_until_complete(
            fetch_data_async(
                pool, start_date, end_date, required_users, salt,
                antenna_details, antenna_modifier))
        # print(len(user2data.keys()))
        temp_data_dir = os.path.join(data_dir, get_salt(16))
        os.mkdir(temp_data_dir)
        for key, val in user2data.items():
            csv_file = os.path.join(temp_data_dir, key + '.csv')
            with open(csv_file, 'w') as fp:
                csv_writer = csv.writer(fp)
                for row in val:
                    csv_writer.writerow(row)
        weights_file = os.path.join(temp_data_dir, 'weights.json')
        with open(weights_file, 'w') as fp:
            json.dump(user2weights, fp)
        # node monitors when `run.txt` is formed inside the data directory
        # as soon as directory is formed, it sets status as running.
        with open(os.path.join(data_dir, 'run.txt'), 'w') as fp:
            fp.write('Execution started')
        dir_queue.put((temp_data_dir, weights_file))
    loop.run_until_complete(pool.close())
    dir_queue.put('done')

