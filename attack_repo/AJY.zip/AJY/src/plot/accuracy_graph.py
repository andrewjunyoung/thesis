# author: Andrew J. Young
# Description: Plots a graph showing the trends in (training | testing) accuracy
# for each of the classifiers used to train the membership inference attack
# model.

ACCURACY_RESULTS_DIR = "out/accuracy"
CLASSIFIER_NAMES = ["LR", "KNN", "RF", "MLP"]


# Data files are stored in:
#   <ACCURACY_RESULTS_DIR>/(test|train)/<classifier_name>.txt

plot_graph(data

def main():
    plot_graph(data = "training")
    plot_graph(data = "testing")
