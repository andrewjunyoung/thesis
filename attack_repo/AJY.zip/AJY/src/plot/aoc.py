from pandas import read_pickle
from matplotlib.pyplot import (figure, legend, draw, show, xlim, legend,
        savefig, xlabel, ylabel)
from src.settings.main import *

## Begin constants #############################################################

USEFUL_COLS = ['cab', 'cl', 'auc']

############################################################### End constants ##
## Begin function definitions ##################################################

def plot_axis(ax, x_vals, y_vals, classifier_name, color, line):
    ax.plot(
            x_vals, y_vals, label = classifier_name, c = color, ls = line,
            linewidth = 2
            )
    return ax


def get_aoc(data):
    return 1 / len(data) * sum(data)


def plot_median_auc_curve():
    # We will use this to iterate over all results.
    res = {group_size: read_pickle(RESULTS_DIR + 'res_' + str(group_size) + '.pkl')
            for group_size in GROUP_SIZES}

    # We need to store median values to plot.
    medians = {name: list() for name in CLASSIFIER_NAMES}

    for group_size, df in res.items():
        classifiers = {name: df[df.cl == name].loc[:, USEFUL_COLS]
                for name in CLASSIFIER_NAMES}

        for classifier_name, classifier in classifiers.items():
            classifier = classifier.sort_values(['auc', 'cab'])
            classifier = classifier.reset_index()
            # median = classifier.iloc[len(classifier) // 2]['auc']
            aoc = get_aoc(classifier['auc'].tolist())
            medians[classifier_name].append(aoc)


    fig = figure()
    fig.show()
    ax = fig.add_subplot(111)

    xlabel("Aggregation size (m)")
    ylabel("Area over the curve")

    i = 0
    for classifier_name, vals in medians.items():
        ax = plot_axis(
                ax, GROUP_SIZES, vals, classifier_name, COLORS[i], LINES[i]
                )
        i += 1
    print(medians)


    legend(loc=2, prop={'size': LEGEND_SIZE / 1.5}, bbox_to_anchor=(0.8, 1))
    draw()
    #savefig(IMAGES_DIR + str(group_size))
    savefig(IMAGES_DIR + 'median_auc')


if __name__ == '__main__':
    plot_median_auc_curve()

#################################################### End function definitions ##

