from pandas import read_pickle, Series, concat, DataFrame
from matplotlib.pyplot import (figure, legend, draw, show, xlim, legend, savefig,
        xlabel, ylabel, title)
from src.settings.main import *
from sorted_users import *

## Begin constants #############################################################

USEFUL_COLS = ['cab', 'cl', 'auc']

sorterIndex = dict(zip(sorted_users,range(len(sorted_users))))

############################################################### End constants ##
## Begin function definitions ##################################################

def plot_axis(ax, classifier, classifier_name, color, line):
    ax.plot(classifier.auc, classifier.percent, label=classifier_name,
            c=color, ls=line, linewidth=2)

    return ax


def get_aoc(data):
    return 1 / len(data) * sum(data)


def plot_auc_curve():
    res = {group_size: read_pickle(RESULTS_DIR + 'res_' + str(group_size) + '.pkl')
            for group_size in GROUP_SIZES}

    for group_size, df in res.items():
        classifiers = {name: df[df.cl == name].loc[:, USEFUL_COLS]
                for name in CLASSIFIER_NAMES}

        fig = figure()
        fig.show()
        ax = fig.add_subplot(111)
        lims = xlim()
        xlim([0, 1.0])

        xlabel("Area under curve (AUC)")
        ylabel("CDF - Cabs")

        i = 0
        for classifier_name, classifier in classifiers.items():
            print(classifier)
            classifier['rank'] = classifier['cab'].apply(lambda x: sorterIndex[x])
            classifier = classifier.sort_values(['rank'])
            classifier = classifier.reset_index()
            classifier['percent'] = classifier.index / len(classifier)

            classifiers[classifier_name] = classifier
            ax = plot_axis(ax, classifier, classifier_name, COLORS[i], LINES[i])
            i += 1

        legend(loc=2, prop={'size': LEGEND_SIZE})
        draw()
        savefig(IMAGES_DIR + "im_trying_" + str(group_size))


if __name__ == '__main__':
    plot_auc_curve()

#################################################### End function definitions ##

