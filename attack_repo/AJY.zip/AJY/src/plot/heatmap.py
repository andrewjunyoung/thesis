# -*- encoding: utf-8 -*-

"""
heatmap.py

Description: A program to create a heatmap from the targets' data frames.
Author: Andrew J. Young at Imperial College London
"""

## Begin imports ###############################################################

# API imports.
from numpy import zeros, int
from pandas import read_pickle
from matplotlib.pyplot import subplots, cm, colorbar, savefig, close

# Program file imports.
from src.settings.main import *

################################################################# End imports ##
## Begin heatmap plotting ######################################################

# Plot a heatmap of the aggregates over time.
def plot_heatmap():
    data = read_pickle(TARGETS_DF_FILTERED_FILE)

    heatmap = zeros(
            (N_EPOCHS, N_CELLS_ON_AN_AXIS, N_CELLS_ON_AN_AXIS), dtype=int
            )
    df_counts = data.groupby(
            ["epoch", "lat", "long"], as_index = False
            ).cab.count()

    # Aggregate the number of targets for each region.
    for _, row in df_counts.iterrows():
    	heatmap[row.epoch - MIN_EPOCH, row.lat, row.long] = row.cab

    # Plot the aggregated heatmap (over all epochs) to find out which
    # region blocks contribute.
    aggr = heatmap.sum(axis = 0)
    fig, ax = subplots()
    heat = ax.pcolor(aggr, cmap=cm.Greys)
    cbar = colorbar(heat)
    ax.set_xlabel('Latitude', fontsize=14)
    ax.set_ylabel('Longitude', fontsize=14)
    cbar.set_label('Cabs in ROIs over time', fontsize=14)
    savefig(HEATMAP_FILE, bbox_inches='tight')
    close()

if __name__ == "__main__":
    plot_heatmap()

######################################################## End heatmap plotting ##
