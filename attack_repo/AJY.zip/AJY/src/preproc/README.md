README:

This is a code for pre-processing the SFC taxi GPS dataset according to the
procedure described in the paper:

Knock Knock, Who’s There? Membership Inference on Aggregate Location Data

https://arxiv.org/pdf/1708.06145.pdf

---------------------
Pre-processing steps:
---------------------

1) Extract the contents of the original SFC data (obtained from
https://crawdad.org/epfl/mobility/20090224/) in the folder called
'cabspottingdata/'.

2) Run the script 'pre\_process\_to\_pkl.py' to generate a pickle file called
'target\_df.pkl' that contains the trips of all the taxis.

3) Run the script 'filter.py' to keep only the relevant data:

  - coordinates in the downtown of San Francisco which are mapped to a 10 x 10
    uniform grid
  - 3 weeks of data, from 2008-05-19 (Monday) to 2008-06-08 (Sunday), in 1 h
    intervals.

The resulting data will be stored on the pickle file called
'target\_df\_filtered.pkl'. For visual purposes, the script will also plot a
heatmap of the aggregated (over time) number of cab trips on the defined grid.

4) Finally, create a folder called 'ground\_truth'. Then, run the script
'ground\_truth.py' to populate the binary location matrices of the cabs (which
are saved as '.npz' files in the 'ground\_truth' folder). The script will also
save a pickle file called 'cabs.pkl' with the cab identifiers which might be
useful for later use.

--------------------------------
Steps to sample mobility groups:
--------------------------------

5) We sample 50 people from each mobility group using the script
'sample\_mobility.py'. Running this will first sort users according to their
mobility (defined in section TODO of the paper). Next, it classifies users as
"high", "medium", or "low" mobility. After this, it will sample 50 users from
each mobility groups, and output these into 3 files as specified in the script.
