## Begin imports ###############################################################

from pandas import read_pickle, DataFrame, concat
from numpy import savez, load, where, zeros
from tqdm import tqdm
from sys import stdout
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
import multiprocessing

from src.settings.main import *

################################################################# End imports ##

def save_sparse_csr(filename, array):
    savez(
            filename, data=array.data, indices=array.indices,
            indptr=array.indptr, shape=array.shape
            )


def load_sparse_csr(filename):
    loader = load(filename)
    return csr_matrix(
            (loader['data'], loader['indices'], loader['indptr']),
            shape = loader['shape']
            )


# function to get those column indexes that sum up to zero
def zero_sum_index(matrix):
    col_sum = matrix.sum(axis = 0)
    zero_idx = where(col_sum == 0)
    return zero_idx


def get_target_data(data, target):
    return data.query('target == @target')


def get_ground_truth(target, group_by_target):
    # The ground truth matrix of binary values, i.e. indicates presence at a
    # ROI per time epoch
    ground_truth = lil_matrix((N_ROIS, N_EPOCHS), dtype=int)

    if DATA_SET == "SFC":
        for _, row in group_by_target.get_group(target).iterrows():
            ground_truth[regions_dict[(row.lat, row.long)], row.epoch -
                    MIN_EPOCH] = 1
    if DATA_SET == "CDR":
        for _, row in group_by_target.get_group(target).iterrows():
            ground_truth[row.point_id, row.epoch - MIN_EPOCH] = 1

    # Assign a value of 1 to the 'NaN' ROI for all epochs without events for
    # the target.
    zero_idx = zero_sum_index(ground_truth.toarray())

    # then, assign 1 to the 'NaN' station for those indexes
    ground_truth[NULL_ROI, zero_idx] = 1

    # save the file to disk
    ground_truth = ground_truth.tocsr()
    save_sparse_csr(GROUND_TRUTH_DIR + str(target) + '.npz', ground_truth)


# If a target appears more than once during the same epoch, only report the ROI
# that it occurred in the most
def remove_duplicate_roi_reports(target_data):
    target = target_data['target'].iloc[0]
    rows = []
    for epoch in set(target_data.epoch.unique()):
        subset_df = target_data[target_data.epoch == epoch]
        if DATA_SET == "CDR":
            subset_df = subset_df.loc[:, ["point_id"]]
        if DATA_SET == "SFC":
            subset_df = subset_df.loc[:, ["lat", "long"]]

        # Get the single representative location.
        if DEFENSES["One ROI per epoch"] == "Mode":
            location = subset_df.apply(tuple, 1).mode()[0]
        if DEFENSES["One ROI per epoch"] == "Random":
            location = subset_df.apply(tuple, 1).sample(1).iloc[0]

        if DATA_SET == "CDR":
            rows.append([target, location[0], epoch])
        elif DATA_SET == "SFC":
            rows.append([target, location[0], location[1], epoch])


    return DataFrame(rows, columns=COLUMNS)


if DATA_SET == "SFC":
    # Create a dictionary mapping grid cells to ROI IDs.
    regions_dict = dict()
    k = 0
    for i in range(0, N_CELLS_ON_AN_AXIS):
        for j in range(0, N_CELLS_ON_AN_AXIS):
            regions_dict[(i, j)] = k
            k = k + 1

def main():
    pool = multiprocessing.Pool(processes=N_PROCESSES)

    # import the pickle with the reduced regions
    data = read_pickle(TARGETS_DF_FILTERED_FILE)

    if DEFENSES["One ROI per epoch"]:
        roi_counts = data['target'].value_counts()
        targets = roi_counts.index.values.tolist()

        print("Splitting target data for preproc.")
        targets_data = pool.starmap(get_target_data, [[data, target] for target
            in targets])

        print("Removing duplicate ROI reports.")
        data_frames = pool.imap(remove_duplicate_roi_reports, targets_data)
        data = concat(data_frames, ignore_index=True)

        data.to_pickle(TARGETS_DF_FILTERED_FILE)


    unique_targets = data.target.unique().tolist()
    n_unique_targets = len(unique_targets) # 534 targets for SFC.

    # save the target IDs for later use
    df = DataFrame({'target': unique_targets})
    df.to_pickle(TARGETS_FILE)

    group_by_target = data.groupby(['target'])

    print("Creating ground truth matrices.")
    pool.starmap(get_ground_truth, [[target, group_by_target] for target in unique_targets])
    print("Done creating ground truth matrices.")

if __name__ == "__main__":
    main()
