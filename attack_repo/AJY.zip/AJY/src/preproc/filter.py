## Begin imports ###############################################################

from numpy import interp, zeros, int
from pandas import read_pickle, to_pickle, concat
from datetime import datetime
from src.settings.main import *
from multiprocessing import Pool

from src.defenses.geo_indistinguishability import geo_ind_df

################################################################# End imports ##
## Begin main method ###########################################################

def apply_geo_ind_one(target_df):
    return geo_ind_df(DEFENSES["Geo-indistinguishability"], target_df,
            ID2LATLONG)


def get_target_data(data, target):
    return data.query('target == @target')


def apply_geo_ind(data):
    pool = Pool(processes=N_PROCESSES)

    print("Applying geo-indistinguishability.")

    roi_counts = data['target'].value_counts()
    targets = roi_counts.index.values.tolist()

    targets_data = pool.starmap(get_target_data, [[data, target] for target
        in targets])

    data_frames = pool.imap(apply_geo_ind_one, targets_data)
    data = concat(data_frames, ignore_index=True)

    return data


def main():
    data = read_pickle(TARGETS_DF_FILE)

    minTime, maxTime = data.epoch.min(), data.epoch.max()

    if DATA_SET == "SFC":

        # Print some statistics about the data before filtering.
        latMin, latMax = data.lat.min(), data.lat.max()
        longMin, longMax = data.long.min(), data.long.max()
        print("Min, max latitude: ", latMin, latMax)
        print("Min, max longitude: ", longMin, longMax)
        print("Min, max time: ", datetime.fromtimestamp(minTime).isoformat(),
              datetime.fromtimestamp(maxTime).isoformat())

        # Restrict the latitude, longitude, and time within a certain range.
        purge_mask = data.lat.map(lambda x: (x > MIN_LAT) & (x < MAX_LAT))
        data = data[purge_mask]
        purge_mask = data.long.map(lambda x: (x > MIN_LONG) & (x < MAX_LONG))
        data = data[purge_mask]

        # Print new statistics about the data after filtering.
        latMin, latMax = data.lat.min(), data.lat.max()
        longMin, longMax = data.long.min(), data.long.max()
        print("Min, max latitude: ", latMin, latMax)
        print("Min, max longitude: ", longMin, longMax)

        # map the data to latitude cells, longitude cells and time epochs
        data["lat"] = data["lat"].map(
                lambda x: interp(
                    x, [latMin, latMax], [0, N_CELLS_ON_AN_AXIS - 1]
                    )
                ).round().astype(int)
        data["long"] = data["long"].map(
                lambda x: interp(
                    x, [longMin, longMax], [0, N_CELLS_ON_AN_AXIS - 1]
                    )
                ).round().astype(int)

    data["epoch"] = data["epoch"].map(
            lambda x: interp(x, [minTime, maxTime], [0, N_EPOCHS - 1])
            ).round().astype(int)

    purge_mask = data.epoch.map(lambda x: (x >= MIN_EPOCH) & (x < MAX_EPOCH))
    data = data[purge_mask]
    data = data.drop_duplicates()

    if DEFENSES["Geo-indistinguishability"]:
        apply_geo_ind(data)


    data.to_pickle(TARGETS_DF_FILTERED_FILE)

if __name__ == "__main__":
    main()

############################################################# End main method ##

