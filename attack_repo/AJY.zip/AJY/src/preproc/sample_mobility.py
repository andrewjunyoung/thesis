from pandas import read_pickle, DataFrame, concat
from numpy import array_split
from scipy.sparse import lil_matrix
from scipy.sparse import csr_matrix
from tqdm import tqdm
from sys import stdout
import multiprocessing
from src.settings.main import *

# Prints statistics about our targets' mobility data for comparison with the paper.
def print_mobility_stats(roi_counts, n_targets):
    print("Max mobility: " + str(roi_counts[0]))
    print("Median mobility: " + str(roi_counts[n_targets // 2]))
    print("Min mobility: " + str(roi_counts[n_targets- 1]))


# Splits the given data into n dataframes according to mobility.
def get_n_mobility_groups(data, N_MOBILITY_GROUPS, SAMPLE_GROUP_SIZE):
    # Get a sorted list of each target's mobility (the count of how many times
    # it appears in `data`).
    roi_counts = data['target'].value_counts()
    sorted_targets = roi_counts.index.values.tolist()
    print(sorted_targets)
    n_targets = len(sorted_targets)
    group_size = int(N_TARGETS // N_MOBILITY_GROUPS)

    # print_mobility_stats(roi_counts, N_TARGETS)

    # Assign each target to a mobility group.
    MOBILITY_GROUPS = [sorted_targets[i : i + SAMPLE_GROUP_SIZE]
                       for i in range(0, N_TARGETS, SAMPLE_GROUP_SIZE)]

    print(MOBILITY_GROUPS)

    mobility_group_dfs = list()
    for mobility_group in MOBILITY_GROUPS:
        mobility_group_df = data[data['target'].isin(mobility_group)]
        mobility_group_dfs.append(mobility_group_df)

    return mobility_group_dfs


def main(data_file_path, N_MOBILITY_GROUPS, SAMPLE_SIZE, N_EPOCHS, MIN_EPOCH):
    pool = multiprocessing.Pool(processes=15)

    print("Creating mobility groups from data.")

    data = read_pickle(data_file_path)

    # Classify users into one of 3 mobility groups
    MOBILITY_GROUPS = get_n_mobility_groups(
            data, N_MOBILITY_GROUPS, SAMPLE_SIZE
            )

    for i, mobility_group in enumerate(MOBILITY_GROUPS):
        sample = mobility_group.sample(SAMPLE_SIZE)
        sample.to_pickle(MOBILITY_CABS_DIR
                + "group" + str(i + 1) + ".pkl")


if __name__ == "__main__":
    print("Beginning sampling.")
    main(
            TARGETS_DF_FILTERED_FILE, N_MOBILITY_GROUPS,
            MOBILITY_GROUP_SAMPLE_SIZE, N_EPOCHS, MIN_EPOCH
            )
    print("Sampling complete.")

