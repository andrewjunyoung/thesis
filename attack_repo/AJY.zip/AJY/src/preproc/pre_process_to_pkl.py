## Begin imports ###############################################################

# APIs
from pandas import DataFrame, read_csv, concat
from xml.etree import ElementTree
from os import path, walk
import operator
import re
from collections import OrderedDict
from datetime import datetime
import multiprocessing

# Internal
from src.settings.main import *
from src.defenses.geo_indistinguishability import geo_ind_df

################################################################# End imports ##
## Begin constants #############################################################

# controlling whether to read the data from the original files or not
EXTRACT = True

DATE_TIME_FORMAT = "%Y-%m-%d %H:%M:%S+00:00"

if DATA_SET == "SFC":
    PARSER_PARAMS = {
                "usecols": [0, 1, 3],
                "names": NAMES,
                "delim_whitespace" : True
                }
if DATA_SET == "CDR":
    PARSER_PARAMS = {
                "usecols": [0, 1],
                "names": NAMES,
                "skiprows": [0],
                "converters": {
                    "epoch": lambda t: int(datetime.strptime(t,
                        DATE_TIME_FORMAT).timestamp()),
                    # This next line assumes only antenna_ids which are in the
                    # POINT_IDS list appear in the data.
                    "point_id": lambda i: POINT_IDS.index(int(i))
                    }
                }

TARGET_NAMES_FILE_PATH = RAW_DATA_DIR + TARGET_NAMES_FILE

############################################################### End constants ##
## Begin utility functions #####################################################

def file_name(target):
    return RAW_DATA_DIR + "new_" + target + '.txt'


def purge_lat(data, MIN_LAT, MAX_LAT):
    purge_mask = data.lat.map(lambda x: (x > MIN_LAT) & (x < MAX_LAT))
    return data[purge_mask]


def purge_long(data, MIN_LONG, MAX_LONG):
    purge_mask = data.long.map(lambda x: (x > MIN_LONG) & (x < MAX_LONG))
    return data[purge_mask]


def get_file_names(RAW_DATA_DIR):
    file_names = []
    for (_, _, files) in walk(RAW_DATA_DIR):
        file_names = files
        # Call «break» to only search the top level directory in RAW_DATA_DIR.
        break
    return file_names


def read_from_xml_file(FILE_PATH):
    f = open(FILE_PATH, 'rt')
    xmlDocData = f.read()
    f.close()

    targets_XML = [ElementTree.XML(item) for item in xmlDocData.splitlines()]
    targets_updates = {item.get("id"): int(item.get("updates"))
            for item in targets_XML}
    return targets_updates


def target_name(FILE_NAME):
    matchObject = re.match(r'new_(.*)\.txt', FILE_NAME, re.M|re.I)
    return matchObject.group(1)


def process_target(target, *args):
    target_df = read_csv(file_name(target), **PARSER_PARAMS)
    target_df["target"] = target

    return target_df

####################################################### End utility functions ##
## Begin main ##################################################################

def main():
    if path.isfile(TARGET_NAMES_FILE_PATH):
        # Read the file "_targets.txt" to get the names of the targets.
        targets_updates = read_from_xml_file(TARGET_NAMES_FILE_PATH)

        print("Maximum number of updates: ", max(targets_updates.items(),
              key=operator.itemgetter(1)))
        print("Minimum number of updates: ", min(targets_updates.items(),
              key=operator.itemgetter(1)))
    else:
        # Look up target_names from within the system
        FILE_NAMES = get_file_names(RAW_DATA_DIR)
        target_names = [target_name(file_name) for file_name in FILE_NAMES]
        targets_updates = [(target_name, None) for target_name in target_names]

    print("Total number of targets: ", len(targets_updates))

    if (EXTRACT):
        print('Starting processing of targets. Please be patient...')

        pool = multiprocessing.Pool(processes=N_PROCESSES)
        data = DataFrame(columns=NAMES)

        if DATA_SET == "SFC":
            data_frames = pool.starmap(process_target, targets_updates.items())
        if DATA_SET == "CDR":
            data_frames = pool.starmap(process_target, targets_updates)

        data = concat(data_frames, ignore_index=True)

        # Discard points which are outside of our consideration.
        if DATA_SET == "SFC":
            data = purge_lat(data, MIN_LAT, MAX_LAT)
            data = purge_long(data, MIN_LONG, MAX_LONG)

        data.to_pickle(TARGETS_DF_FILE)


if __name__ == '__main__':
    main()

#################################################################### End main ##

