## Begin data set settings #####################################################

DATA_SET = "SFC"

if DATA_SET == "SFC":
    from src.settings.sfc_config import *
if DATA_SET == "CDR":
    from src.settings.cdr_config import *

####################################################### End data set settings ##
## Begin defenses ##############################################################

# Must set the value to `False` to turn off a defense. See "README.md" for more
# details about configuring defenses.
DEFENSES = {
        "One ROI per epoch": False,
        "Low count suppression": False,
        # ("Normal", 100), ("Laplacian", "Delta / epsilon", <epsilon>)
        "Add noise": False,
        "Geo-indistinguishability": False
        }

################################################################ End defenses ##
## Begin file settings #########################################################

# Files: @Andrea
CABS_FILE = 'out/targets.pkl'
TARGET_NAMES_FILE = '_targets.txt'
TARGETS_DF_FILE = 'out/df_targets.pkl'
HEATMAP_FILE = "out/imgs/heatmap.pdf"
TARGETS_DF_FILTERED_FILE = "out/df_targets_filtered.pkl"
TARGETS_FILE = 'out/targets.pkl'

# Directories: @Andrea
MOBILITY_CABS_DIR = 'out/mobility_groups/'
IMAGES_DIR = 'out/imgs/'
RESULTS_DIR = 'out/results/'
USER_DFS_DIR = 'out/user_dfs/'
GROUND_TRUTH_DIR = "out/ground_truth/"

##################################################### End file settings ########
## Begin epoch settings ########################################################

EPOCH_DURATION = 60 # in minutes.
EPOCHS_PER_DAY = (24 * 60) // EPOCH_DURATION # 24 * 60 minutes in 1 day.
WEEKLY_EPOCHS = 7 * EPOCHS_PER_DAY # 7 days in 1 week.
N_EPOCHS = WEEKS_OF_DATA * WEEKLY_EPOCHS

#################################################### End epoch settings ########
## Begin misc ##################################################################

GROUP_SIZES = [5, 10, 50, 100]#, 200, 300]#, 300, 1000, 10000, 15000, 20000, 25000, 30000]

N_FEATURES = N_ROIS * 8 # We extract 8 features for each ROI.
CLASSIFIER_NAMES = ["LR", "KNN", "RF", "MLP"]

N_THREADS = 9
N_PROCESSES = 16

N_TARGETS = 150 # Equivalent to beta value in P17.

# The proportion of individuals the attacker knows about.
# Equivalent to alpha in P17.
SUBSET_SIZE = 0.2

#################################################################### End misc ##
## Begin plotting settings #####################################################

COLORS = ['blue', 'darkturquoise', 'black', 'fuchsia']
LINES = ['-', '--', '-.', ':']

LEGEND_SIZE = 17

####################################################### End plotting settings ##
## Begin attack group settings #################################################

MOBILITY_GROUP_SAMPLE_SIZE = 50
N_MOBILITY_GROUPS = 3 # The number of mobility groups used for sampling users.

################################################### End attack group settings ##

