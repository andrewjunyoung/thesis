## Begin imports ###############################################################

# APIs
import pytest
from pandas import DataFrame

# Internal
from src.defenses.geo_indistinguishability import geo_ind_df

################################################################# End imports ##
## Begin constants #############################################################

THRESHOLD = 10

############################################################### End constants ##
## Begin utility functions #####################################################

def get_df():
    return DataFrame([["a", 13, 0],
                      ["a", 14, 1],
                      ["a", 10, 2]])

def get_id2latlong():
    return {13:
            14:
            10: }

####################################################### End utility functions ##
## Begin tests #################################################################

def test_zeros():
    run_all_cases(0, True)
    run_all_cases(0.0, True)

def test_ints_less_than_threshold():
    run_all_cases(THRESHOLD - 1, True)

def test_ints_more_than_threshold():
    run_all_cases(THRESHOLD + 1, False)

def test_equal_to_threshold():
    run_all_cases(THRESHOLD, False)
    run_all_cases(THRESHOLD + 0.0, False)
    run_all_cases(THRESHOLD + 0.1 - 0.1, False)

def test_floats_less_than_threshold():
    run_all_cases(THRESHOLD - 0.5, True)
    run_all_cases(THRESHOLD - 0.1, True)

def test_floats_more_than_threshold():
    run_all_cases(THRESHOLD + 0.5, False)
    run_all_cases(THRESHOLD + 0.1, False)

"""
Other cases which weren't considered for tests:
    - max_int
    - min_int
    - More non-int types.
"""

################################################################### End tests ##
