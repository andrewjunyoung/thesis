## Begin imports ###############################################################

# APIs
import pytest
from unittest.mock import patch
from numpy import zeros, ones

# Internal
from src.defenses.output_noise_addition import add_noise, scale_factor

################################################################# End imports ##
## Begin utility functions #####################################################

def zeros_array():
    return zeros((10, 10))

def ones_array():
    return ones((10, 10))

####################################################### End utility functions ##
## Begin tests #################################################################

def test_scale_factor():
    assert scale_factor(("Laplacian", "Delta / epsilon", 0.1), 5) == 50.0
    assert scale_factor(("Laplacian", "1 / epsilon", 0.1), 5) == 10.0
    assert scale_factor(("Normal", 0.1), 5) == 0.1

def test_scale_factor_exit():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
            scale_factor(("Invalid"), 5)
    assert pytest_wrapped_e.type == SystemExit

@patch("numpy.random.laplace", lambda x, y: 1)
@patch("numpy.random.normal", lambda x, y: 1)
def test_add_noise():
    assert (add_noise(
            zeros_array(), ("Laplacian", "Delta / epsilon", 0.1), 5
            ) == ones_array()).all()
    assert (add_noise(
            zeros_array(), ("Laplacian", "1 / epsilon", 0.1), 5
            ) == ones_array()).all()
    assert (add_noise(zeros_array(), ("Normal", 0.1), 5) == ones_array()).all()


def test_add_noise_exit():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
            add_noise(zeros_array(), ("Invalid"), 5)
    assert pytest_wrapped_e.type == SystemExit

################################################################### End tests ##
