## Begin imports ###############################################################

# APIs
import pytest
from numpy import array, zeros
from numpy.random import randint

# Internal
from src.defenses.low_count_suppression import is_low_count

################################################################# End imports ##
## Begin constants #############################################################

THRESHOLD = 10

############################################################### End constants ##
## Begin utility functions #####################################################

def array_all(x):
    vector = [x] * 10
    matrix = [vector] * 10
    return array(matrix)

def array_singleton(x):
    return array([[x]])

def random_array(x):
    matrix = zeros((10, 10))

    for i in range(10):
        for j in range(10):
            # Fill the matrix with what should be valid values.
            matrix[i, j] = randint(THRESHOLD, 100)

    # Randomly insert x into the matrix.
    i_coord = randint(0, 10)
    j_coord = randint(0, 10)
    matrix[i_coord, j_coord] = x

    return array(matrix)

def run_all_cases(x, result):
    assert is_low_count(random_array(x), THRESHOLD) == result
    assert is_low_count(array_singleton(x), THRESHOLD) == result
    assert is_low_count(array_all(x), THRESHOLD) == result

####################################################### End utility functions ##
## Begin tests #################################################################

def test_zeros():
    run_all_cases(0, True)
    run_all_cases(0.0, True)

def test_ints_less_than_threshold():
    run_all_cases(THRESHOLD - 1, True)

def test_ints_more_than_threshold():
    run_all_cases(THRESHOLD + 1, False)

def test_equal_to_threshold():
    run_all_cases(THRESHOLD, False)
    run_all_cases(THRESHOLD + 0.0, False)
    run_all_cases(THRESHOLD + 0.1 - 0.1, False)

def test_floats_less_than_threshold():
    run_all_cases(THRESHOLD - 0.5, True)
    run_all_cases(THRESHOLD - 0.1, True)

def test_floats_more_than_threshold():
    run_all_cases(THRESHOLD + 0.5, False)
    run_all_cases(THRESHOLD + 0.1, False)

"""
Other cases which weren't considered for tests:
    - max_int
    - min_int
    - More non-int types.
"""

################################################################### End tests ##
