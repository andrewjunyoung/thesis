## Begin imports ###############################################################

import pytest

from pandas import read_pickle
from src.preproc.pre_process_to_pkl import *
from pandas.util.testing import assert_frame_equal

################################################################# End imports ##
## Begin constants #############################################################

# Directories
RAW_DATA_DIR = "src/data/"
# Files
TARGET_NAMES_FILE_PATH = RAW_DATA_DIR + "_targets.txt"
EXPECTED_SFC_FILE = "tests/expected/sfc/df_targets.pkl"
EXPECTED_CDR_FILE = "tests/expected/cdr/df_targets.pkl"

MIN_LAT = 37.73
MAX_LAT = 37.80
MIN_LONG = -122.45
MAX_LONG = -122.37

N_PROCESSES = 7

############################################################### End constants ##
## Begin utility functions #####################################################

def run_and_assert_same(EXPECTED_FILE, TARGETS_DF_FILE):
    main()
    expected = read_pickle(EXPECTED_FILE)
    actual = read_pickle(TARGETS_DF_FILE)
    print("Expected:", expected)
    print("Actual:", actual)
    assert_frame_equal(actual, expected)

####################################################### End utility functions ##

def test_pre_process_to_pkl_sfc():
    DATA_SET = "SFC"
    TARGETS_DF_FILE = EXPECTED_SFC_FILE

    run_and_assert_same(EXPECTED_SFC_FILE, TARGETS_DF_FILE)

def test_pre_process_to_pkl_cdr():
    DATA_SET = "CDR"
    TARGETS_DF_FILE = EXPECTED_CDR_FILE

    run_and_assert_same(EXPECTED_CDR_FILE, TARGETS_DF_FILE)

