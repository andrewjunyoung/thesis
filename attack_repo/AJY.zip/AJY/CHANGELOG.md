# Changelog

## Version 0.0.79 [2019-05-01]
### Added
- CHANGELOG.md with version 1 info.
- README.md
  - Setup.
  - Running from the commandline.
  - Setting defenses.
  - FAQs.
- Attacks:
  - «subset of locations released prior» (as in Pyrgelis et al 17).
  - «same locations as released prior» (as in Pyrgelis et al 17).
  - «different locations than released prior» (as in Pyrgelis et al 17).
  - Principal component analysis for «subset» attack.
- Defenses:
  - «Winner takes all» defense (reports only the modal ROI for each epoch).
- Plotting:
  - Heatmap.
  - AUC curve.
  - median AUC curve.
- Refactored and restructured attack code.
- Time optimizations for each attack.
- Up to date list of requirements.

### Todo
- Write PCA code to work for any attack.
- Generalize the attack to work with the CDR dataset.
- Fix makefile to work for directory spawning.
