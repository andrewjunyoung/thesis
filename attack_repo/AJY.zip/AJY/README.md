# Knock knock, who's there? A reimplemented attack model on aggregate location data

![python](https://img.shields.io/badge/Python-3.7.2-blue.svg)


<!-- vim-markdown-toc GFM -->

* [Setup](#setup)
  * [Installing dependencies](#installing-dependencies)
  * [Executing from the command line](#executing-from-the-command-line)
* [Data sets](#data-sets)
  * [San Francisco cabs (SFC) data set](#san-francisco-cabs-sfc-data-set)
    * [Sanitation](#sanitation)
  * [Call detail records (CDR) data subset](#call-detail-records-cdr-data-subset)
* [Running the MI attack from the command line](#running-the-mi-attack-from-the-command-line)
* [Using defenses](#using-defenses)
  * [List of defenses](#list-of-defenses)
* [FAQs](#faqs)

<!-- vim-markdown-toc -->


## Setup

### Installing dependencies

This project coded with Python 3.7.2. Backwards compatibility is not guaranteed.

All package dependencies not included with Python 3 are included in
`requirements.txt`.

To install these packages automatically:

1. Install [Pip3](https://pip.pypa.io/en/stable/installing/).

1. Run `pip3 install -r <path_to_requirements.txt>`.

### Executing from the command line

In order to use imports in this project, you will need to include the top level
directory for this project in your `$PYTHONPATH` environment variable (the top
level of the project is the directory containing this file, `README.md`)

1. Run `export PYTHONPATH=$PYTHONATH:<path_to_project>/`

## Data sets

### San Francisco cabs (SFC) data set

The San Francisco cabs data set details the movement of 534 different cabs
around San Francisco over a period of just over 3 weeks.

The data set itself contains the latitude and longitude associated with a
particular cab at a specified time, expressed as seconds since epoch (00:00:00
on Jan 1, 1970).

The data is provided as a 534 \texttt{.txt} files containing data, and one
additional file \texttt{\_targets.txt}. The 534 data files are each associated
with 1 cab, and list the latitude, longitude, and time stamp for that vehicle at
various times over the period the data was taken over.

Each row of the data files is structured as:

\texttt{<latitude: float> <longitude: float> <is\_occupied: int>
<seconds\_since\_epoch: int>\\n},

where "occupied" is 1 if the cab is carrying a passenger, and 0 otherwise.
Latitude and longitude are each given to an accuracy of 5 decimal places.

\texttt{\_targets.txt} is an XML file that lists the details of all data files
in the directory so that they can be quickly and easily parsed during
preprocessing.

ROIs are created by building a 10 x 10 grid from downtown San Francisco.
Latitude - longitude reports which fall in a particular grid square are assigned
that ROI. A null ROI is included as well, totaling 101 ROIs.

#### Sanitation

For the purpose of the MI attack, some data was removed from the SFC data set.
To begin with, records from outside of downtown San Francisco were excluded.
Downtown San Francisco was taken to be:

Latitude: 37.73000 - 37.80000

Longitude: -122.45 - -122.37

### Call detail records (CDR) data subset

Individuals: 153,997 unique callers (the full data set has ~ 2 M individuals)
ROIs: 220 (points), plus a 'NaN' ROI.

This subset of the full data set contains only individuals who have >= 30
events in the data set.

Some antenna IDs are different but the tower's the same (At most 2 antennas
share the same location). There are 220 antenna IDs within the city of interest,
which may not all be distinct towers.

The data comes in CSV files. The first line of each CSV file is `event_time,
antenna_id`. This is followed by 

## Running the MI attack from the command line

This repository contains several different attacks within it:

1. «Subset of locations released prior»
1. «Same locations as released prior»
1. «Different locations than released prior»

To run the attacks, follow the procedure below.

1. Look at the `config.py` file, located in `<path_to_project>/src/config.py`,
   and ensure that all global variables are configured how you want them. In
   particular, make sure that directories that point to files and directories
   are correct, and that the flags set for the attack are as you want them.

1. Change directory to the top level directory of this project.

1. Run the command which corresponds to the attack you want to run.

| Attack                                    | Command         |
| ----------------------------------------- | --------------- |
| «Subset of locations released prior»      | `make subset`   |
| «Same locations as released prior»        | `make same`     |
| «Different locations than released prior» | `make diff`     |
| «Subset of locations» with PCA            | `make pca`      |

## Using defenses

It is possible to run the membership inference attack while using defenses which
aim to reduce the accuracy of the adversary's attack. A list of possible
defenses is stored in the config file as a dictionary called DEFENSES.

Defenses can be set using flags. To turn off a particular defense _d_, simply
set the value associated with _d_ to `False`. For example, to turn off the `"Add
noise"` attack, set DEFENSES as follows:

```
DEFENSES = {
        ...
        "Add noise": False,
        ...
        }
```

### List of defenses

To turn off any defense, set the associated value to `False`.

| Defense name                 | Value                                   | Effect                                                                                                   |
|------------------------------|-----------------------------------------|----------------------------------------------------------------------------------------------------------|
| `"One ROI per epoch"`        | `Mode`                                  | Also called «Winner takes all».<br>Only reports 1 ROI per individual per epoch (the mode for that epoch) |
|                              | `Random`                                | Only reports 1 ROI per individual per epoch, selected at random                                          |
| `"Low count suppression"`    | `<threshold>`                           | Discludes aggregates from the training set if the values in the aggregate are below `threshold`.         |
| `"Add noise"`                | `("Laplacian", "Delta / epsilon", <e>)` | Adds laplacian noise with the scale parameter `group_size / e`                                           |
|                              | `("Laplacian", "1 / epsilon", <e>)`     | Adds laplacian noise with the scale parameter `1 / e`                                                    |
|                              | `("Normal", x)`                         | Adds normal noise with the scale parameter x                                                             |
| `"Geo-indistinguishability"` | `<epsilon>`                             | Applies geo-indistinguishability with the spatial paramater `<epsilon>` |

## FAQs

> Does the attack output data as it goes, or all in one at the end?

Results are output into the directories that you specify as soon as they're
produced by the MI attack.

> If my code crashes do I have to restart from the very beginning?

You can reload any results which you generated previously. In order to reload
files from an attack, make sure the `USER_DFS_DIR` is set to the directory
containing the dataframes for your users, and these will be reloaded
automatically when you next run an attack.
